# BPA Fixed Ports (Never Change)

- API: 3000
- mother: 3100
- shop: 3101
- clinic: 3102
- admin: 3103
- owner: 3104

This is a **hard rule** for scripts, envs, docker compose, proxies and docs.
