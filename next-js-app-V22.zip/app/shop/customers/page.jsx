"use client";

import PlaceholderPage from "@/src/components/PlaceholderPage";

export default function Page() {
  return <PlaceholderPage title="Customers" backHref="/shop" />;
}
