"use client";

import { useMemo, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { detectAuthType } from "@/src/utils/authHelpers";

function apiBase() {
  return process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3000";
}

async function apiPost(path, body) {
  const res = await fetch(`${apiBase()}${path}`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.message || "Request failed");
  return json;
}

export default function LoginPage() {
  const sp = useSearchParams();
  const router = useRouter();
  const invited = sp.get("invited") === "1";
  const registered = sp.get("registered") === "1";

  const [identifier, setIdentifier] = useState(""); // email or phone
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const authType = useMemo(() => {
    if (!identifier.trim()) return null;
    return detectAuthType(identifier);
  }, [identifier]);

  const canSubmit = useMemo(() => {
    return identifier.trim().length > 0 && password.length > 0 && !loading && authType?.type;
  }, [identifier, password, loading, authType]);

  async function onSubmit(e) {
    e.preventDefault();
    if (!canSubmit) return;
    setErr("");
    setLoading(true);
    try {
      const detected = detectAuthType(identifier);
      if (!detected.type) {
        setErr("Please enter a valid email or phone number");
        setLoading(false);
        return;
      }

      const payload = detected.type === "email"
        ? { email: detected.normalized, password }
        : { phone: detected.normalized, password };

      const response = await apiPost("/api/v1/auth/login", payload);

      // Handle redirect based on user role if provided
      if (response?.user?.redirectPath) {
        router.push(response.user.redirectPath);
      } else {
        router.push("/");
      }
    } catch (e2) {
      setErr(e2?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container" style={{ maxWidth: 560, padding: 24 }}>
      <div className="text-center mb-24">
        <h3 className="mb-2">Login</h3>
        <p className="text-muted">Sign in to your account</p>
      </div>

      {invited ? (
        <div className="alert alert-success">
          Your account was created successfully. Please login to continue.
        </div>
      ) : null}

      {registered ? (
        <div className="alert alert-success">
          Registration successful! Please login to continue.
        </div>
      ) : null}

      {err ? <div className="alert alert-danger">{err}</div> : null}

      <form onSubmit={onSubmit} className="card p-16">
        <div className="mb-12">
          <label className="form-label">
            Email or Phone Number
            {authType?.type && (
              <span className="badge badge-sm badge-light ms-2">
                {authType.type === "email" ? "📧 Email" : "📱 Phone"}
              </span>
            )}
          </label>
          <input
            className="form-control"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder="Enter your email or phone number"
            type="text"
            autoComplete="username"
          />
          {identifier && !authType?.type && (
            <div className="text-danger small mt-4">
              Please enter a valid email or phone number
            </div>
          )}
        </div>

        <div className="mb-12">
          <label className="form-label">Password</label>
          <input
            className="form-control"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            autoComplete="current-password"
          />
        </div>

        <button className="btn btn-primary w-100" type="submit" disabled={!canSubmit}>
          {loading ? "Signing in..." : "Sign in"}
        </button>

        <div className="text-center mt-16">
          <p className="text-muted small mb-0">
            Don't have an account?{" "}
            <Link href="/register" className="text-primary">
              Register here
            </Link>
          </p>
        </div>
      </form>
    </div>
  );
}
