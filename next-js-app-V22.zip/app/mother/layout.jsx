import MasterLayout from "@/src/masterLayout/MasterLayout";

export default function MotherLayout({ children }) {
  return <MasterLayout>{children}</MasterLayout>;
}
