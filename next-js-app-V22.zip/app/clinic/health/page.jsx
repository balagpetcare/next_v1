export default function HealthPage() {
  return (
    <div>
      <h2>communitypetclinic.com — Health</h2>
      <p>Status: OK ✅</p>
      <p>This page exists in each site to confirm routing works.</p>
    </div>
  );
}
