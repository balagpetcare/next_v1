"use client";

import { useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { apiPost } from "@/lib/api";
import { detectAuthType } from "@/src/utils/authHelpers";
import AuthFooter from "@/src/bpa/components/AuthFooter";

export default function AdminLoginPage() {
  const router = useRouter();
  const sp = useSearchParams();
  const nextUrl = sp.get("next") || "/admin";

  const [identifier, setIdentifier] = useState(""); // email or phone
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const authType = useMemo(() => {
    if (!identifier.trim()) return null;
    return detectAuthType(identifier);
  }, [identifier]);

  const canSubmit = useMemo(() => {
    return identifier.trim().length > 0 && password.length > 0 && !loading && authType?.type;
  }, [identifier, password, loading, authType]);

  async function onSubmit(e) {
    e.preventDefault();
    if (!canSubmit) return;
    setError("");
    setLoading(true);
    try {
      const detected = detectAuthType(identifier);
      if (!detected.type) {
        setError("Please enter a valid email or phone number");
        setLoading(false);
        return;
      }

      const payload = detected.type === "email"
        ? { email: detected.normalized, password }
        : { phone: detected.normalized, password };

      // ✅ Admin-only login (backend MUST gate via DB whitelist)
      // Uses HttpOnly cookie set by the API.
      await apiPost("/api/v1/admin/auth/login", payload);

      router.replace(nextUrl);
      router.refresh();
    } catch (err) {
      setError(err?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="auth bg-base d-flex flex-wrap min-vh-100">
      {/* Left illustration */}
      <div className="auth-left d-lg-block d-none">
        <div className="d-flex align-items-center flex-column h-100 justify-content-center">
          <img src="/assets/images/auth/auth-img.png" alt="Auth" />
        </div>
      </div>

      {/* Right form */}
      <div className="auth-right py-32 px-24 d-flex flex-column justify-content-center">
        <div className="max-w-464-px mx-auto w-100">
          <div>
            <Link href="/" className="mb-40 max-w-290-px d-inline-block">
              <img src="/assets/images/logo.png" alt="BPA" />
            </Link>
            <h4 className="mb-12">Admin Sign In</h4>
            <p className="mb-32 text-secondary-light text-lg">
              Sign in with your existing backend login. This page stores nothing in localStorage — it uses an HttpOnly cookie set by the API.
            </p>
          </div>

          {error ? (
            <div className="alert alert-danger py-12 px-16 radius-8 mb-20" role="alert">
              {error}
            </div>
          ) : null}

          <form onSubmit={onSubmit}>
            <div className="icon-field mb-8">
              <span className="icon top-50 translate-middle-y">
                <i className={authType?.type === "email" ? "ri-mail-line" : "ri-phone-line"} />
              </span>
              <input
                type="text"
                className="form-control h-56-px bg-neutral-50 radius-12"
                placeholder="Email or Phone Number"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                autoComplete="username"
                required
                disabled={loading}
              />
            </div>
            {authType?.type && (
              <div className="mb-8 text-secondary-light text-sm d-flex align-items-center gap-8">
                <span className="badge badge-sm badge-light">
                  {authType.type === "email" ? "📧 Email" : "📱 Phone"}
                </span>
                {authType.type === "phone" && (
                  <span>Tip: you can type with +880 or spaces — backend normalizes it.</span>
                )}
              </div>
            )}
            {identifier && !authType?.type && (
              <div className="text-danger small mb-8">
                Please enter a valid email or phone number
              </div>
            )}

            <div className="position-relative mb-20">
              <div className="icon-field">
                <span className="icon top-50 translate-middle-y">
                  <i className="ri-lock-password-line" />
                </span>
                <input
                  type="password"
                  className="form-control h-56-px bg-neutral-50 radius-12"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  required
                  disabled={loading}
                />
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary-600 text-sm btn-sm px-12 py-16 w-100 radius-12"
              disabled={!canSubmit}
            >
              {loading ? "Signing in..." : "Sign In"}
            </button>

            <div className="mt-24 text-center">
              <span className="text-secondary-light text-sm">
                After login, you’ll be redirected to: <code>{nextUrl}</code>
              </span>
            </div>
          </form>

          <AuthFooter />
        </div>
      </div>
    </section>
  );
}
