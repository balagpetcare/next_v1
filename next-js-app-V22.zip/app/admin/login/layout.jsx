export default function AdminLoginLayout({ children }) {
  // Standalone auth layout (no sidebar/topbar)
  return <>{children}</>;
}
