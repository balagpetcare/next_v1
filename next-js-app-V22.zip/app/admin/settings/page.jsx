export default function Page() {
  return (
    <div style={{padding: 18 }}>
      <h2 style={{margin: 0, marginBottom: 8 }}>Settings</h2>
      <p style={{color: "#6b7280" }}>
        Placeholder page for <code>/admin/settings</code>. Wire real module UI next.
      </p>
    </div>
  );
}
