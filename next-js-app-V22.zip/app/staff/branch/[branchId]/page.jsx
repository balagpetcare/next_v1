"use client";

import { useEffect, useState, useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { apiGet } from "@/lib/api";
import Card from "@/src/bpa/components/ui/Card";
import PageHeader from "@/src/bpa/components/ui/PageHeader";

export default function StaffBranchDashboardPage() {
  const params = useParams();
  const router = useRouter();
  const branchId = useMemo(() => String(params?.branchId || ""), [params]);

  const [branch, setBranch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [metrics, setMetrics] = useState(null);
  const [accessStatus, setAccessStatus] = useState(null);
  const [checkingAccess, setCheckingAccess] = useState(true);

  useEffect(() => {
    if (!branchId) return;
    
    // Store branch ID in localStorage
    if (typeof window !== "undefined") {
      localStorage.setItem("bpa_branch_id", branchId);
    }

    async function loadBranch() {
      try {
        setLoading(true);
        setError("");
        setCheckingAccess(true);
        
        // First check branch access
        try {
          const accessCheck = await apiGet(`/api/v1/branch-access/check/${branchId}`);
          const hasAccess = accessCheck?.data?.hasAccess || accessCheck?.success;
          
          if (!hasAccess) {
            // Get detailed status
            const requestsResponse = await apiGet("/api/v1/branch-access/my-requests").catch(() => ({ success: false }));
            if (requestsResponse.success && requestsResponse.data) {
              const permission = requestsResponse.data.find(
                (p) => p.branchId === Number(branchId)
              );
              if (permission) {
                setAccessStatus(permission.status);
                // Redirect to waiting page if pending/revoked/expired
                if (permission.status !== "APPROVED") {
                  router.push(`/staff/branch/${branchId}/waiting`);
                  return;
                }
              } else {
                // No permission found, redirect to waiting
                router.push(`/staff/branch/${branchId}/waiting`);
                return;
              }
            } else {
              // No access, redirect to waiting
              router.push(`/staff/branch/${branchId}/waiting`);
              return;
            }
          }
          
          setAccessStatus("APPROVED");
        } catch (accessError) {
          console.error("Access check error:", accessError);
          // If access check fails, try to continue (might be manager/owner)
        } finally {
          setCheckingAccess(false);
        }
        
        // Fetch branch details (using staff-accessible endpoint)
        const branchData = await apiGet(`/api/v1/branches/${branchId}`);
        const branchInfo = branchData?.data || branchData;
        setBranch(branchInfo);

        // Fetch basic metrics (simplified for staff)
        try {
          const today = new Date();
          const lastWeek = new Date(today);
          lastWeek.setDate(lastWeek.getDate() - 7);

          const [todaySales, weekSales, ordersRes] = await Promise.all([
            apiGet(`/api/v1/reports/sales?branchId=${branchId}&startDate=${today.toISOString().split("T")[0]}&groupBy=day`).catch(() => ({ data: { summary: { totalSales: 0, totalOrders: 0 } } })),
            apiGet(`/api/v1/reports/sales?branchId=${branchId}&startDate=${lastWeek.toISOString().split("T")[0]}&groupBy=day`).catch(() => ({ data: { summary: { totalSales: 0, totalOrders: 0 } } })),
            apiGet(`/api/v1/orders?branchId=${branchId}&limit=5`).catch(() => ({ data: { items: [] } })),
          ]);

          setMetrics({
            todaySales: todaySales?.data?.summary?.totalSales || 0,
            weekSales: weekSales?.data?.summary?.totalSales || 0,
            todayOrders: todaySales?.data?.summary?.totalOrders || 0,
            weekOrders: weekSales?.data?.summary?.totalOrders || 0,
            recentOrders: ordersRes?.data?.items || ordersRes?.items || [],
          });
        } catch (metricsError) {
          console.warn("Failed to load metrics:", metricsError);
          // Metrics are optional, don't fail the page
        }
      } catch (e) {
        setError(e?.message || "Failed to load branch");
      } finally {
        setLoading(false);
      }
    }
    loadBranch();
  }, [branchId]);

  if (loading || checkingAccess) {
    return (
      <div className="container py-40">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-16 text-secondary-light">
            {checkingAccess ? "Checking access..." : "Loading branch dashboard..."}
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container py-40">
        <Card>
          <div className="alert alert-danger" role="alert">
            {error}
          </div>
          <div className="mt-20">
            <button
              className="btn btn-primary"
              onClick={() => router.push("/staff/branches")}
            >
              Back to Branches
            </button>
          </div>
        </Card>
      </div>
    );
  }

  if (!branch) {
    return (
      <div className="container py-40">
        <Card>
          <div className="text-center">
            <h5>Branch Not Found</h5>
            <p className="text-secondary-light">
              The branch you're looking for doesn't exist or you don't have access to it.
            </p>
            <button
              className="btn btn-primary mt-20"
              onClick={() => router.push("/staff/branches")}
            >
              Back to Branches
            </button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="container py-40">
      <PageHeader
        title={branch.name || "Branch Dashboard"}
        subtitle={`Welcome to ${branch.name || "your branch"}`}
      />

      {/* Quick Metrics */}
      {metrics && (
        <div className="row g-20 mb-30">
          <div className="col-md-3">
            <Card>
              <div className="d-flex align-items-center justify-content-between">
                <div>
                  <p className="text-secondary-light text-sm mb-4">Today's Sales</p>
                  <h4 className="mb-0">৳{Number(metrics.todaySales || 0).toLocaleString()}</h4>
                </div>
                <i className="ri-money-dollar-circle-line text-primary-600 fs-32"></i>
              </div>
            </Card>
          </div>
          <div className="col-md-3">
            <Card>
              <div className="d-flex align-items-center justify-content-between">
                <div>
                  <p className="text-secondary-light text-sm mb-4">Today's Orders</p>
                  <h4 className="mb-0">{metrics.todayOrders || 0}</h4>
                </div>
                <i className="ri-shopping-cart-line text-primary-600 fs-32"></i>
              </div>
            </Card>
          </div>
          <div className="col-md-3">
            <Card>
              <div className="d-flex align-items-center justify-content-between">
                <div>
                  <p className="text-secondary-light text-sm mb-4">This Week Sales</p>
                  <h4 className="mb-0">৳{Number(metrics.weekSales || 0).toLocaleString()}</h4>
                </div>
                <i className="ri-line-chart-line text-primary-600 fs-32"></i>
              </div>
            </Card>
          </div>
          <div className="col-md-3">
            <Card>
              <div className="d-flex align-items-center justify-content-between">
                <div>
                  <p className="text-secondary-light text-sm mb-4">This Week Orders</p>
                  <h4 className="mb-0">{metrics.weekOrders || 0}</h4>
                </div>
                <i className="ri-file-list-3-line text-primary-600 fs-32"></i>
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="row g-20">
        <div className="col-md-6">
          <Card title="Quick Actions" subtitle="Common tasks for this branch">
            <div className="d-grid gap-12">
              <Link
                href={`/shop/orders?branchId=${branchId}`}
                className="btn btn-outline-primary d-flex align-items-center justify-content-between"
              >
                <span>
                  <i className="ri-shopping-cart-line me-8"></i>
                  View Orders
                </span>
                <i className="ri-arrow-right-line"></i>
              </Link>
              <Link
                href={`/shop/inventory?branchId=${branchId}`}
                className="btn btn-outline-primary d-flex align-items-center justify-content-between"
              >
                <span>
                  <i className="ri-store-line me-8"></i>
                  View Inventory
                </span>
                <i className="ri-arrow-right-line"></i>
              </Link>
              <Link
                href={`/shop/products?branchId=${branchId}`}
                className="btn btn-outline-primary d-flex align-items-center justify-content-between"
              >
                <span>
                  <i className="ri-product-hunt-line me-8"></i>
                  View Products
                </span>
                <i className="ri-arrow-right-line"></i>
              </Link>
              {branch.types?.some((t) => t.type?.code === "CLINIC") && (
                <Link
                  href={`/clinic/appointments?branchId=${branchId}`}
                  className="btn btn-outline-primary d-flex align-items-center justify-content-between"
                >
                  <span>
                    <i className="ri-calendar-line me-8"></i>
                    View Appointments
                  </span>
                  <i className="ri-arrow-right-line"></i>
                </Link>
              )}
              <Link
                href={`/shop/pos?branchId=${branchId}`}
                className="btn btn-primary d-flex align-items-center justify-content-between"
              >
                <span>
                  <i className="ri-shopping-bag-line me-8"></i>
                  Open POS
                </span>
                <i className="ri-arrow-right-line"></i>
              </Link>
            </div>
          </Card>
        </div>

        <div className="col-md-6">
          <Card title="Recent Orders" subtitle="Latest orders for this branch">
            {metrics?.recentOrders && metrics.recentOrders.length > 0 ? (
              <div className="list-group list-group-flush">
                {metrics.recentOrders.slice(0, 5).map((order) => (
                  <div
                    key={order.id}
                    className="list-group-item d-flex align-items-center justify-content-between px-0"
                  >
                    <div>
                      <p className="mb-4 fw-semibold">Order #{order.id}</p>
                      <p className="text-secondary-light text-sm mb-0">
                        {order.createdAt
                          ? new Date(order.createdAt).toLocaleString()
                          : "N/A"}
                      </p>
                    </div>
                    <div className="text-end">
                      <p className="mb-0 fw-semibold">
                        ৳{Number(order.total || 0).toLocaleString()}
                      </p>
                      <span
                        className={`badge ${
                          order.status === "COMPLETED"
                            ? "bg-success"
                            : order.status === "PENDING"
                            ? "bg-warning"
                            : "bg-secondary"
                        }`}
                      >
                        {order.status || "PENDING"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-secondary-light text-center py-20">
                No recent orders
              </p>
            )}
          </Card>
        </div>
      </div>

      {/* Branch Info */}
      <div className="row g-20 mt-20">
        <div className="col-12">
          <Card title="Branch Information">
            <div className="row">
              <div className="col-md-6">
                <p className="mb-8">
                  <span className="text-secondary-light">Branch Name:</span>{" "}
                  <span className="fw-semibold">{branch.name}</span>
                </p>
                {branch.types && branch.types.length > 0 && (
                  <p className="mb-8">
                    <span className="text-secondary-light">Type:</span>{" "}
                    <span className="fw-semibold">
                      {branch.types.map((t) => t.type?.nameEn || t.type?.code).join(", ")}
                    </span>
                  </p>
                )}
              </div>
              <div className="col-md-6">
                <p className="mb-8">
                  <span className="text-secondary-light">Status:</span>{" "}
                  <span
                    className={`badge ${
                      branch.status === "ACTIVE" ? "bg-success" : "bg-secondary"
                    }`}
                  >
                    {branch.status || "UNKNOWN"}
                  </span>
                </p>
                <button
                  className="btn btn-outline-secondary btn-sm"
                  onClick={() => router.push("/staff/branches")}
                >
                  Switch Branch
                </button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
