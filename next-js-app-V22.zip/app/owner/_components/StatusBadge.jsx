"use client";

export default function StatusBadge({ status }) {
  const s = String(status || "").toUpperCase();
  const map = {
    DRAFT: "secondary",
    SUBMITTED: "info",
    PENDING_REVIEW: "warning",
    APPROVED: "success",
    REJECTED: "danger",
    CANCELLED: "dark",
    SUSPENDED: "dark",
  };
  const cls = map[s] || "secondary";

  return <span className={"badge text-bg-" + cls}>{s || "—"}</span>;
}
