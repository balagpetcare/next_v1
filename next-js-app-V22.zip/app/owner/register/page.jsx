"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { apiPost } from "@/lib/api";
import { detectAuthType, validateRegistration } from "@/src/utils/authHelpers";
import AuthFooter from "@/src/bpa/components/AuthFooter";

export default function OwnerRegisterPage() {
  const router = useRouter();

  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const authType = useMemo(() => {
    if (!identifier.trim()) return null;
    return detectAuthType(identifier);
  }, [identifier]);

  const validation = useMemo(() => {
    return validateRegistration({
      identifier,
      password,
      name,
    });
  }, [identifier, password, name]);

  const canSubmit = useMemo(() => {
    if (loading) return false;
    if (!validation.valid) return false;
    if (password !== confirmPassword) return false;
    if (password.length < 4) return false;
    return true;
  }, [loading, validation, password, confirmPassword]);

  async function onSubmit(e) {
    e.preventDefault();
    if (!canSubmit) return;

    setError("");
    setLoading(true);

    try {
      const detected = detectAuthType(identifier);
      if (!detected.type) {
        setError("Please enter a valid email or phone number");
        setLoading(false);
        return;
      }

      const payload = {
        password,
        ...(detected.type === "email" ? { email: detected.normalized } : { phone: detected.normalized }),
        ...(name.trim() ? { name: name.trim() } : {}),
        ...(address.trim() ? { address: address.trim() } : {}),
        isOwner: true,
      };

      await apiPost("/api/v1/auth/register", payload);
      
      // Redirect to login with success message
      router.push("/owner/login?registered=1");
    } catch (e) {
      setError(e?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="auth bg-base d-flex flex-wrap min-vh-100">
      <div className="auth-left d-lg-block d-none">
        <div className="d-flex align-items-center flex-column h-100 justify-content-center">
          <img src="/assets/images/auth/auth-img.png" alt="Auth" />
        </div>
      </div>

      <div className="auth-right py-32 px-24 d-flex flex-column justify-content-center">
        <div className="max-w-464-px mx-auto w-100">
          <div>
            <Link href="/" className="mb-40 max-w-290-px d-inline-block">
              <img src="/assets/images/logo.png" alt="BPA" />
            </Link>
            <h4 className="mb-12">Owner Registration</h4>
            <p className="mb-32 text-secondary-light text-lg">
              Create a new account to manage your organization and branches.
            </p>
          </div>

          {error ? (
            <div className="alert alert-danger py-12 px-16 radius-8 mb-20" role="alert">
              {error}
            </div>
          ) : null}

          <form onSubmit={onSubmit}>
            <div className="icon-field mb-16">
              <input
                type="text"
                className={`form-control h-56-px bg-neutral-50 radius-12 ${validation.errors.identifier ? "is-invalid" : ""}`}
                placeholder="Email or Phone Number"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                autoComplete="username"
                required
                disabled={loading}
              />
              <span className="icon">
                <i className={authType?.type === "email" ? "ri-mail-line" : "ri-phone-line"} />
              </span>
              {validation.errors.identifier && (
                <div className="text-danger small mt-4">{validation.errors.identifier}</div>
              )}
              {identifier && !authType?.type && !validation.errors.identifier && (
                <div className="text-danger small mt-4">
                  Please enter a valid email or phone number
                </div>
              )}
            </div>

            <div className="icon-field mb-16">
              <input
                type="text"
                className="form-control h-56-px bg-neutral-50 radius-12"
                placeholder="Full Name (Optional)"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
                disabled={loading}
              />
              <span className="icon">
                <i className="ri-user-3-line" />
              </span>
            </div>

     
            <div className="icon-field mb-16">
              <input
                type="password"
                className={`form-control h-56-px bg-neutral-50 radius-12 ${validation.errors.password ? "is-invalid" : ""}`}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
                required
                disabled={loading}
                minLength={4}
              />
              <span className="icon">
                <i className="ri-lock-password-line" />
              </span>
              {validation.errors.password && (
                <div className="text-danger small mt-4">{validation.errors.password}</div>
              )}
            </div>

            <div className="icon-field mb-20">
              <input
                type="password"
                className={`form-control h-56-px bg-neutral-50 radius-12 ${password !== confirmPassword && confirmPassword ? "is-invalid" : ""}`}
                placeholder="Confirm Password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                autoComplete="new-password"
                required
                disabled={loading}
              />
              <span className="icon">
                <i className="ri-lock-password-line" />
              </span>
              {password !== confirmPassword && confirmPassword && (
                <div className="text-danger small mt-4">Passwords do not match</div>
              )}
            </div>

            <button
              type="submit"
              className="btn btn-primary-600 text-sm btn-sm px-12 py-16 w-100 radius-12"
              disabled={!canSubmit}
            >
              {loading ? "Creating Account..." : "Create Account"}
            </button>

            <div className="mt-24 text-center">
              <p className="text-secondary-light text-sm mb-0">
                Already have an account?{" "}
                <Link href="/owner/login" className="text-primary-600 fw-semibold">
                  Sign In
                </Link>
              </p>
            </div>
          </form>

          <AuthFooter />
        </div>
      </div>
    </section>
  );
}
