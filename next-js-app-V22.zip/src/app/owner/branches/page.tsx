// @ts-nocheck
// Re-export the WowDash-based Owner Branches screen.
// Root `app/owner/*` contains the full-feature pages; `src/app` is the active app router.
export { default } from "@/app/owner/branches/page.jsx";
