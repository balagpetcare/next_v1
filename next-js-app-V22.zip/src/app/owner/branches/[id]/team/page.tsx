// @ts-nocheck
export { default } from "@/app/owner/branches/[id]/team/page.jsx";
