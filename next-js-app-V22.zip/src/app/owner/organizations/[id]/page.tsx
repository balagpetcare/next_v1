// @ts-nocheck
export { default } from "@/app/owner/organizations/[id]/page.jsx";
