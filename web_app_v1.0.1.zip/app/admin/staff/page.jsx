export default function Page() {
  return (
    <div style={{padding: 18 }}>
      <h2 style={{margin: 0, marginBottom: 8 }}>Staff</h2>
      <p style={{color: "#6b7280" }}>
        Placeholder page for <code>/admin/staff</code>. Wire real module UI next.
      </p>
    </div>
  );
}
