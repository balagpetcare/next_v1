// Prefer same-origin calls (via Next.js rewrite proxy) to avoid CORS issues.
// If you explicitly set NEXT_PUBLIC_API_BASE_URL (e.g. https://api.example.com),
// requests will go directly there (and that server must allow CORS + credentials).
const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE_URL ||
  "";

/**
 * Safely parse JSON (or return a text message object).
 */
async function parseJsonSafe(res: Response): Promise<any> {
  const text = await res.text().catch(() => "");
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return { message: text };
  }
}

export async function apiFetch<T = any>(path: string, opts: RequestInit = {}): Promise<T> {
  const url = path.startsWith("http") ? path : `${API_BASE}${path}`;

  let res: Response;
  try {
    res = await fetch(url, {
      ...opts,
      // ✅ HttpOnly cookie support
      credentials: "include",
      // ✅ avoid caching auth/session calls
      cache: "no-store",
      headers: {
        ...(opts.headers || {}),
      },
    });
  } catch {
    // Network/DNS/connection error
    throw new Error("Failed to fetch");
  }

  if (!res.ok) {
    const data = await parseJsonSafe(res);
    const msg =
      data?.message ||
      data?.error ||
      data?.detail ||
      `Request failed (${res.status})`;
    throw new Error(msg);
  }

  return (await parseJsonSafe(res)) as T;
}

export function apiGet<T = any>(path: string) {
  return apiFetch<T>(path, { method: "GET" });
}

export function apiPost<T = any>(path: string, body?: unknown) {
  return apiFetch<T>(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body ?? {}),
  });
}

export function apiPut<T = any>(path: string, body?: unknown) {
  return apiFetch<T>(path, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body ?? {}),
  });
}

export function apiDelete<T = any>(path: string, body?: unknown) {
  return apiFetch<T>(path, {
    method: "DELETE",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body ?? {}),
  });
}
