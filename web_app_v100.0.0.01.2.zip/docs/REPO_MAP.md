# REPO_MAP (to be generated in Cursor)

This file is intentionally a placeholder.

## What to generate
1) API routes map (backend-api)
2) Next.js routes map (per app: mother/shop/clinic/admin/owner)
3) Key Prisma models overview
4) Key env variables & runtime notes

## Instruction
Use Cursor to scan the repository and fill this document. Do not change code while generating the map.
