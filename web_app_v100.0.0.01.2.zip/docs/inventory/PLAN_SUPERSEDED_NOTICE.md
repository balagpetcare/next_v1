# Plan Superseded Notice

Date: 2026-02-04

**This plan is superseded by docs/master-plan/MASTER_PLAN.md.**

## What this refers to

- Previous (superseded) Cursor plan file(s) located in the workspace:
  - `D:/BPA_Data/backend-api/.cursor/plans/inventory-requests-upgrade_38f82c9f.plan.md`
  - (Other plans exist in `D:/BPA_Data/backend-api/.cursor/plans/`, but the inventory plan above is what this notice is about.)

## What remains valid

- Existing inventory UI notes remain as implementation reference:
  - `bpa_web/docs/inventory/STOCK_REQUEST_UI_OWNER.md`

