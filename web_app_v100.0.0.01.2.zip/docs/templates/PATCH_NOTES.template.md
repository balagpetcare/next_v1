# PATCH_NOTES

## Package
- App: (API / owner / admin / clinic / shop / mother)
- Version: X.Y.Z
- Type: PATCH / MINOR / MAJOR
- Date: YYYY-MM-DD

## Summary
(1-3 lines)

## Changes
- 

## Impact / Compatibility
- Breaking changes: NO / YES (explain)
- Ports changed: NO (must remain fixed)
- DB migration required: NO / YES (if YES, see MIGRATION.md)

## How to Verify
- Commands:
  - 
- Routes / Screens:
  - 

## Rollback
- Steps to rollback this patch:
  - 
