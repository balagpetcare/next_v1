# Upcoming Tasks (Shortlist)

- Staff login routes fix (owner/staff)
- Role-based dashboard visibility (menus + pages)
- Restore missing Next.js routes (404 issues)
- Owner branch team pages
- Email & notification template integration
- Verification review UI (admin side)
