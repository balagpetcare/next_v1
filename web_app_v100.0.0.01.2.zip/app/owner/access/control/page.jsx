"use client";

// Canonical IA route: /owner/access/control (alias for staff-access hub)
export { default } from "../../staff-access/page";
