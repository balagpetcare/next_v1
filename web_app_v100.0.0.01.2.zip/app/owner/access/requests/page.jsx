"use client";

// Canonical IA route: /owner/access/requests (alias for branches/access-requests)
export { default } from "../../branches/access-requests/page";
