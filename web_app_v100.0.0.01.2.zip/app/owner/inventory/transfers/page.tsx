"use client";

import TransfersPage from "@/app/owner/transfers/page";

export default function InventoryTransfersPage() {
  return <TransfersPage />;
}
