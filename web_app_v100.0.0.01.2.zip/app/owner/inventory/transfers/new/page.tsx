"use client";

import TransfersNewPage from "@/app/owner/transfers/new/page";

export default function InventoryTransfersNewPage() {
  return <TransfersNewPage />;
}
