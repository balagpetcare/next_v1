"use client";

import TransferDetailPage from "@/app/owner/transfers/[id]/page";

export default function InventoryTransferDetailWrapper() {
  return <TransferDetailPage />;
}
