"use client";

// Canonical IA route: /owner/staff (alias for staffs list)
export { default } from "../staffs/page";
