/**
 * Producer Auth Layout - Standalone (no sidebar/topbar)
 */
export default function ProducerLoginLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
