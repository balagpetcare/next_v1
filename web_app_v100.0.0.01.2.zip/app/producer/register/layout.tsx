/**
 * Producer Auth Layout - Standalone (no sidebar/topbar)
 */
export default function ProducerRegisterLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
