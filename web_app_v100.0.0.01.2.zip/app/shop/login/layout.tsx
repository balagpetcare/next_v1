/**
 * Shop Auth Layout - Standalone (no sidebar/topbar)
 */
export default function ShopLoginLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
