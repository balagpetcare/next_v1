/**
 * Shop Auth Layout - Standalone (no sidebar/topbar)
 */
export default function ShopRegisterLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
