/**
 * Admin Auth Layout - Standalone (no sidebar/topbar)
 */
export default function AdminRegisterLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
