/**
 * Country Auth Layout - Standalone (no sidebar/topbar)
 */
export default function CountryLoginLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
