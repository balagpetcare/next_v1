/**
 * Clinic Auth Layout - Standalone (no sidebar/topbar)
 */
export default function ClinicRegisterLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
