import MasterLayout from "@/src/masterLayout/MasterLayout";

export default function ClinicLayout({ children }) {
  return <MasterLayout>{children}</MasterLayout>;
}
