/**
 * Clinic Auth Layout - Standalone (no sidebar/topbar)
 */
export default function ClinicLoginLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
