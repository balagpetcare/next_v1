"use client";

import PlaceholderPage from "@/src/components/PlaceholderPage";

export default function Page() {
  return <PlaceholderPage title="Staff" backHref="/clinic" />;
}
