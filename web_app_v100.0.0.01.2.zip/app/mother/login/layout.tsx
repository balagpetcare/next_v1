/**
 * Mother Auth Layout - Standalone (no sidebar/topbar)
 */
export default function MotherLoginLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
