// @ts-nocheck
export { default } from "@/app/owner/branches/[id]/page.jsx";
