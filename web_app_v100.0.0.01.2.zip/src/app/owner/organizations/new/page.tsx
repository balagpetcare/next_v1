// @ts-nocheck
export { default } from "@/app/owner/organizations/new/page.jsx";
