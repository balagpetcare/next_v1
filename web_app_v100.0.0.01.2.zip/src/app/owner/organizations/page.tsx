// @ts-nocheck
export { default } from "@/app/owner/organizations/page.jsx";
