// @ts-nocheck
export { default } from "@/app/owner/staff/page.jsx";
