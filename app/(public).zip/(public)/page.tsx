import HeroSection from "./_components/HeroSection";
import EcosystemSection from "./_components/EcosystemSection";
import HowToStartSection from "./_components/HowToStartSection";
import BenefitsSection from "./_components/BenefitsSection";
import ReportsSection from "./_components/ReportsSection";
import ServiceSalesSection from "./_components/ServiceSalesSection";
import CustomerBenefitsSection from "./_components/CustomerBenefitsSection";
import TestimonialsSection from "./_components/TestimonialsSection";
import TrustSection from "./_components/TrustSection";
import FaqSection from "./_components/FaqSection";
import CtaSection from "./_components/CtaSection";

export default function PublicLandingPage() {
  return (
    <>
      <HeroSection />
      <EcosystemSection />
      <HowToStartSection />
      <BenefitsSection />
      <ReportsSection />
      <ServiceSalesSection />
      <CustomerBenefitsSection />
      <TestimonialsSection />
      <TrustSection />
      <FaqSection />
      <CtaSection />
    </>
  );
}
