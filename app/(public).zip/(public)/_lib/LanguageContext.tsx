"use client";

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import enMessages from "../_locales/en.json";
import bnMessages from "../_locales/bn.json";

const COOKIE_NAME = "landing_locale";
const STORAGE_KEY = "landing_locale";

const messagesMap: Record<string, Record<string, unknown>> = {
  en: enMessages as Record<string, unknown>,
  bn: bnMessages as Record<string, unknown>,
};

export type Locale = "en" | "bn";

type Messages = Record<string, unknown>;

function getNested(obj: Messages, path: string): string | undefined {
  const parts = path.split(".");
  let current: unknown = obj;
  for (const part of parts) {
    if (current == null || typeof current !== "object") return undefined;
    current = (current as Record<string, unknown>)[part];
  }
  return typeof current === "string" ? current : undefined;
}

function setCookie(name: string, value: string, days = 365) {
  if (typeof document === "undefined") return;
  const maxAge = days * 24 * 60 * 60;
  document.cookie = `${name}=${encodeURIComponent(value)}; path=/; max-age=${maxAge}; SameSite=Lax`;
}

function getCookie(name: string): string | null {
  if (typeof document === "undefined") return null;
  const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  return match ? decodeURIComponent(match[2]) : null;
}

type LanguageContextValue = {
  locale: Locale;
  t: (key: string) => string;
  setLocale: (locale: Locale) => void;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function useLanguage(): LanguageContextValue {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("en");

  useEffect(() => {
    const stored = getCookie(COOKIE_NAME) || (typeof localStorage !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null);
    const initial: Locale = stored === "bn" ? "bn" : "en";
    setLocaleState(initial);
  }, []);

  const messages = messagesMap[locale] ?? messagesMap.en;

  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next);
    setCookie(COOKIE_NAME, next);
    if (typeof localStorage !== "undefined") localStorage.setItem(STORAGE_KEY, next);
    if (typeof document !== "undefined") document.documentElement.lang = next === "bn" ? "bn" : "en";
  }, []);

  const t = useCallback(
    (key: string): string => {
      const value = getNested(messages, key);
      return value ?? key;
    },
    [messages]
  );

  const value = useMemo(() => ({ locale, t, setLocale }), [locale, t, setLocale]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}
