"use client";

import { Icon } from "@iconify/react";
import { useLanguage } from "../_lib/LanguageContext";

const items = [
  { icon: "solar:phone-calling-rounded-bold-duotone", titleKey: "item1Title", descKey: "item1Desc" },
  { icon: "solar:bell-bing-bold-duotone", titleKey: "item2Title", descKey: "item2Desc" },
  { icon: "solar:shield-check-bold-duotone", titleKey: "item3Title", descKey: "item3Desc" },
  { icon: "solar:folder-bold-duotone", titleKey: "item4Title", descKey: "item4Desc" },
];

export default function CustomerBenefitsSection() {
  const { t } = useLanguage();

  return (
    <section aria-labelledby="customer-benefits-title">
      <h2 id="customer-benefits-title" className="section-title">
        {t("customerBenefits.title")}
      </h2>
      <div className="jamina-customer-bars">
        {items.map((item, i) => (
          <div key={i} className="jamina-customer-bar">
            <div className="icon-wrap">
              <Icon icon={item.icon} width={40} height={40} aria-hidden="true" />
            </div>
            <div>
              <h3>{t(`customerBenefits.${item.titleKey}`)}</h3>
              <p>{t(`customerBenefits.${item.descKey}`)}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
