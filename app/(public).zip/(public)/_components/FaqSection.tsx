"use client";

import { useLanguage } from "../_lib/LanguageContext";

const faqs = [
  { qKey: "q1", aKey: "a1" },
  { qKey: "q2", aKey: "a2" },
  { qKey: "q3", aKey: "a3" },
  { qKey: "q4", aKey: "a4" },
];

export default function FaqSection() {
  const { t } = useLanguage();

  return (
    <section id="faq" aria-labelledby="faq-title">
      <h2 id="faq-title" className="section-title">
        {t("faq.title")}
      </h2>
      <div className="faq-list">
        {faqs.map((faq, i) => (
          <details key={faq.qKey} className="faq-item" open={i === 0}>
            <summary>{t(`faq.${faq.qKey}`)}</summary>
            <div className="faq-answer">{t(`faq.${faq.aKey}`)}</div>
          </details>
        ))}
      </div>
    </section>
  );
}
