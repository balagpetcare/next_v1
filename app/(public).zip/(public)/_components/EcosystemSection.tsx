"use client";

import { Icon } from "@iconify/react";
import { useLanguage } from "../_lib/LanguageContext";

const cardKeys = [
  { key: "card1", icon: "solar:medical-kit-bold-duotone" },
  { key: "card2", icon: "solar:heart-bold-duotone" },
  { key: "card3", icon: "solar:home-2-bold-duotone" },
  { key: "card4", icon: "solar:bag-bold-duotone" },
  { key: "card5", icon: "solar:cat-bold-duotone" },
] as const;

export default function EcosystemSection() {
  const { t } = useLanguage();

  return (
    <section className="jamina-ecosystem" aria-labelledby="ecosystem-title">
      <h2 id="ecosystem-title" className="section-title">
        {t("ecosystem.title")}
      </h2>
      <p className="section-subtitle">
        {t("ecosystem.subtitle")}
      </p>
      <div className="jamina-ecosystem-hub">
        <div className="jamina-ecosystem-center" aria-hidden="true">
          <Icon icon="solar:users-group-rounded-bold-duotone" width={32} height={32} aria-hidden="true" />
          {t("ecosystem.centerLabel")}
        </div>
        <div className="jamina-ecosystem-cards">
          {cardKeys.map(({ key, icon }) => (
            <div key={key} className="jamina-ecosystem-card">
              <div className="icon-wrap">
                <Icon icon={icon} width={36} height={36} aria-hidden="true" />
              </div>
              <h3>{t(`ecosystem.${key}Title`)}</h3>
              <p>{t(`ecosystem.${key}Desc`)}</p>
            </div>
          ))}
        </div>
        <p className="jamina-ecosystem-caption">
          {t("ecosystem.subtitle")}
        </p>
      </div>
    </section>
  );
}
