"use client";

import React from "react";
import { Icon } from "@iconify/react";
import { useLanguage } from "../_lib/LanguageContext";

const stages = [
  { icon: "solar:hand-shake-bold-duotone", key: "stage1" },
  { icon: "solar:shield-check-bold-duotone", key: "stage2" },
  { icon: "solar:card-bold-duotone", key: "stage3" },
  { icon: "solar:users-group-rounded-bold-duotone", key: "stage4" },
];

export default function ServiceSalesSection() {
  const { t } = useLanguage();

  return (
    <section className="jamina-flow" aria-labelledby="service-sales-title">
      <h2 id="service-sales-title" className="section-title">
        {t("serviceSales.title")}
      </h2>
      <div className="jamina-flow-stages">
        {stages.map((stage, i) => (
          <React.Fragment key={stage.key}>
            {i > 0 && (
              <div className="jamina-flow-arrow" aria-hidden="true">
                →
              </div>
            )}
            <div className="jamina-flow-stage">
              <div className="icon-wrap">
                <Icon icon={stage.icon} width={36} height={36} aria-hidden="true" />
              </div>
              <h3>{t("serviceSales." + stage.key)}</h3>
            </div>
          </React.Fragment>
        ))}
      </div>
      <div className="jamina-stat-callout">
        {t("serviceSales.statCallout")}
      </div>
    </section>
  );
}
