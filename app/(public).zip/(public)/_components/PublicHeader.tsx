"use client";

import Link from "next/link";
import { Icon } from "@iconify/react";
import { useLanguage } from "../_lib/LanguageContext";

export default function PublicHeader() {
  const { locale, t, setLocale } = useLanguage();

  return (
    <header className="jamina-header" role="banner">
      <div className="jamina-header-inner">
        <a href="/" className="jamina-logo" aria-label={t("header.logo")}>
          <Icon icon="solar:leaf-bold" width={24} height={24} className="jamina-logo-icon" aria-hidden="true" />
          <span>{t("header.logo")}</span>
        </a>
        <nav className="jamina-header-nav" aria-label="Main navigation">
          <div className="jamina-lang-switcher">
            <button
              type="button"
              className={"jamina-lang-btn" + (locale === "en" ? " is-active" : "")}
              onClick={() => setLocale("en")}
              aria-pressed={locale === "en"}
              aria-label="English"
            >
              {t("header.langEn")}
            </button>
            <span className="jamina-lang-sep" aria-hidden="true">|</span>
            <button
              type="button"
              className={"jamina-lang-btn" + (locale === "bn" ? " is-active" : "")}
              onClick={() => setLocale("bn")}
              aria-pressed={locale === "bn"}
              aria-label="Bengali"
            >
              {t("header.langBn")}
            </button>
          </div>
          <Link href="/owner/login" className="jamina-header-link">
            {t("header.login")}
          </Link>
          <Link href="/owner/register" className="jamina-btn jamina-btn-primary">
            {t("header.startBusiness")}
          </Link>
        </nav>
      </div>
    </header>
  );
}
