"use client";

import Link from "next/link";
import { useLanguage } from "../_lib/LanguageContext";

export default function HeroSection() {
  const { t } = useLanguage();

  return (
    <section className="jamina-hero" aria-labelledby="hero-title">
      <div className="jamina-hero-wrap">
        <div>
          <h1 id="hero-title" className="jamina-hero-title">
            {t("hero.title")}
          </h1>
          <p className="jamina-hero-subtitle">
            {t("hero.subtitle")}
          </p>
          <div className="jamina-hero-cta">
            <Link
              href="/owner/register"
              className="jamina-btn jamina-btn-primary"
              aria-label={t("hero.ctaPrimary")}
            >
              {t("hero.ctaPrimary")}
            </Link>
            <a
              href="#how-to-start"
              className="jamina-btn"
              aria-label={t("hero.ctaSecondary")}
            >
              {t("hero.ctaSecondary")}
            </a>
          </div>
        </div>
        <div className="jamina-hero-visual">
          <div className="jamina-hero-mockup">
            <div className="mockup-revenue">{t("hero.monthlyRevenue")}</div>
            <div className="mockup-label">{t("hero.dashboardPreview")}</div>
          </div>
        </div>
      </div>
    </section>
  );
}
