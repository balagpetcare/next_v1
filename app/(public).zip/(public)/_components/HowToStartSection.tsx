"use client";

import Link from "next/link";
import { Icon } from "@iconify/react";
import { useLanguage } from "../_lib/LanguageContext";

const steps = [
  { num: 1, icon: "solar:user-check-bold-duotone", titleKey: "step1Title", descKey: "step1Desc" },
  { num: 2, icon: "solar:buildings-2-bold-duotone", titleKey: "step2Title", descKey: "step2Desc" },
  { num: 3, icon: "solar:rocket-2-bold-duotone", titleKey: "step3Title", descKey: "step3Desc" },
];

export default function HowToStartSection() {
  const { t } = useLanguage();

  return (
    <section id="how-to-start" aria-labelledby="how-to-start-title">
      <h2 id="how-to-start-title" className="section-title">
        {t("howToStart.title")}
      </h2>
      <div className="jamina-steps">
        {steps.map((step) => (
          <div key={step.num} className="jamina-step">
            <span className="jamina-step-connector" aria-hidden="true" />
            <div className="jamina-step-node">
              <Icon icon={step.icon} width={28} height={28} aria-hidden="true" />
            </div>
            <h3>{step.num}. {t(`howToStart.${step.titleKey}`)}</h3>
            <p>{t(`howToStart.${step.descKey}`)}</p>
          </div>
        ))}
      </div>
      <p style={{ textAlign: "center", marginTop: "40px" }}>
        <Link href="/owner/register" className="jamina-btn jamina-btn-primary" aria-label={t("howToStart.cta")}>
          {t("howToStart.cta")}
        </Link>
      </p>
    </section>
  );
}
