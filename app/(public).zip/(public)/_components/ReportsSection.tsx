"use client";

import dynamic from "next/dynamic";
import { Icon } from "@iconify/react";
import { demoData } from "../_data/demoData";
import {
  getSalesTrendOptions,
  getCategoryPieOptions,
  getServiceBarOptions,
} from "../_lib/chartConfigs";
import { useLanguage } from "../_lib/LanguageContext";

const Chart = dynamic(() => import("react-apexcharts"), {
  ssr: false,
  loading: () => (
    <div className="chart-skeleton" role="status" aria-label="Loading chart">
      …
    </div>
  ),
});

export default function ReportsSection() {
  const { t } = useLanguage();
  const daily = demoData.salesSummary.daily;
  const categories = demoData.productCategoryBreakdown;
  const services = demoData.servicePopularity;

  const salesTrendOptions = getSalesTrendOptions(daily.map((d) => d.day));
  const salesTrendSeries = [
    { name: "Sales (BDT)", data: daily.map((d) => d.sales) },
  ];

  const pieOptions = getCategoryPieOptions(categories.map((c) => c.category));
  const pieSeries = categories.map((c) => c.percentage);

  const barOptions = getServiceBarOptions(services.map((s) => s.service));
  const barSeries = [{ name: "Bookings", data: services.map((s) => s.count) }];

  return (
    <section id="reports" aria-labelledby="reports-title">
      <h2 id="reports-title" className="section-title">
        {t("reports.title")}
      </h2>
      <p className="section-subtitle">
        {t("reports.subtitle")}
      </p>
      <div className="jamina-reports-wrap">
        <div>
          <ul className="jamina-reports-bullets">
            <li>
              <Icon icon="solar:check-circle-bold" width={24} height={24} className="check-icon" aria-hidden="true" />
              {t("reports.bullet1")}
            </li>
            <li>
              <Icon icon="solar:check-circle-bold" width={24} height={24} className="check-icon" aria-hidden="true" />
              {t("reports.bullet2")}
            </li>
            <li>
              <Icon icon="solar:check-circle-bold" width={24} height={24} className="check-icon" aria-hidden="true" />
              {t("reports.bullet3")}
            </li>
          </ul>
        </div>
        <div className="jamina-reports-dashboard">
          <div className="chart-card">
            <h3>{t("reports.chart1Title")}</h3>
            <Chart
              options={salesTrendOptions}
              series={salesTrendSeries}
              type="line"
              height={260}
              aria-label="Revenue line chart"
            />
          </div>
          <div className="chart-card">
            <h3>{t("reports.chart2Title")}</h3>
            <Chart
              options={pieOptions}
              series={pieSeries}
              type="pie"
              height={240}
              aria-label="Product categories pie chart"
            />
          </div>
          <div className="chart-card">
            <h3>{t("reports.chart3Title")}</h3>
            <Chart
              options={barOptions}
              series={barSeries}
              type="bar"
              height={240}
              aria-label="Services bar chart"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
