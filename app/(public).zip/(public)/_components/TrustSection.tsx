"use client";

import { Icon } from "@iconify/react";
import { useLanguage } from "../_lib/LanguageContext";

const badges = [
  { icon: "solar:shield-check-bold-duotone", key: "badge1" },
  { icon: "solar:lock-password-bold-duotone", key: "badge2" },
  { icon: "solar:headphones-round-sound-bold-duotone", key: "badge3" },
  { icon: "solar:cloud-check-bold-duotone", key: "badge4" },
];

export default function TrustSection() {
  const { t } = useLanguage();

  return (
    <section className="jamina-trust-section" aria-labelledby="trust-title">
      <h2 id="trust-title" className="section-title" style={{ marginBottom: "32px" }}>
        {t("trust.title")}
      </h2>
      <div className="trust-grid">
        {badges.map((b) => (
          <div key={b.key} className="trust-badge">
            <div className="icon-wrap">
              <Icon icon={b.icon} width={40} height={40} aria-hidden="true" />
            </div>
            <span>{t(`trust.${b.key}`)}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
