"use client";

import { Icon } from "@iconify/react";
import { useLanguage } from "../_lib/LanguageContext";

const testimonials = [
  { nameKey: "name1", roleKey: "role1", quoteKey: "quote1", initial: "R" },
  { nameKey: "name2", roleKey: "role2", quoteKey: "quote2", initial: "S" },
  { nameKey: "name3", roleKey: "role3", quoteKey: "quote3", initial: "K" },
];

function Stars() {
  return (
    <span className="stars" aria-hidden="true">
      {[1, 2, 3, 4, 5].map((i) => (
        <Icon key={i} icon="solar:star-bold" width={18} height={18} aria-hidden="true" />
      ))}
    </span>
  );
}

export default function TestimonialsSection() {
  const { t } = useLanguage();

  return (
    <section className="jamina-testimonials-section" aria-labelledby="testimonials-title">
      <h2 id="testimonials-title" className="section-title">
        {t("testimonials.title")}
      </h2>
      <div className="testimonials-grid">
        {testimonials.map((tst, i) => (
          <article key={i} className="testimonial-card">
            <div className="testimonial-avatar">{tst.initial}</div>
            <Stars />
            <blockquote>{t(`testimonials.${tst.quoteKey}`)}</blockquote>
            <div className="author">{t(`testimonials.${tst.nameKey}`)}</div>
            <div className="role">{t(`testimonials.${tst.roleKey}`)}</div>
          </article>
        ))}
      </div>
    </section>
  );
}
