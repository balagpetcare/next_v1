"use client";

import Link from "next/link";
import { useLanguage } from "../_lib/LanguageContext";

export default function CtaSection() {
  const { t } = useLanguage();

  return (
    <section className="landing-section-cta" aria-labelledby="cta-final-title">
      <div className="jamina-cta-wrap">
        <h2 id="cta-final-title" className="section-title">
          {t("cta.title")}
        </h2>
        <p className="section-subtitle">
          {t("cta.subtitle")}
        </p>
        <Link
          href="/owner/register"
          className="jamina-cta-btn"
          aria-label={t("cta.button")}
        >
          {t("cta.button")}
        </Link>
        <p className="jamina-cta-tagline">
          {t("cta.tagline")}
        </p>
      </div>
    </section>
  );
}
