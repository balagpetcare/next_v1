"use client";

// Thin wrapper to expose BranchForm from the shared location-aware module
// SOURCE: org location flow from components/LocationPicker.jsx

import BranchForm from "@/app/owner/_components/branch/BranchForm";

export default BranchForm;
