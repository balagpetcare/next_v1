"use client";

import React from "react";

export default function EditBranchClient({ id, initial }: { id: string; initial: any }) {
  return (
    <div>
      <h1>Edit Branch {id}</h1>
      <p>Component under construction.</p>
    </div>
  );
}
