import MasterLayout from "@/src/masterLayout/MasterLayout";

export default function ShopLayout({ children }) {
  return <MasterLayout>{children}</MasterLayout>;
}
