"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import ImprovedLocationPicker from "@/app/owner/_components/location/ImprovedLocationPicker";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3000";

async function uploadMedia(file) {
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch(`${API_BASE}/api/v1/media/upload`, {
    method: "POST",
    body: fd,
    credentials: "include",
  });
  const j = await res.json().catch(() => null);
  if (!res.ok || !j?.success) throw new Error(j?.message || `Upload failed (${res.status})`);
  return j.data?.id;
}

async function apiPost(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
    credentials: "include",
  });
  const j = await res.json().catch(() => null);
  if (!res.ok || !j?.success) throw new Error(j?.message || `Request failed (${res.status})`);
  return j.data;
}

async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "GET",
    credentials: "include",
    cache: "no-store",
  });
  const j = await res.json().catch(() => null);
  if (!res.ok || !j?.success) throw new Error(j?.message || `Request failed (${res.status})`);
  return j.data;
}

function Alert({ type = "info", children }) {
  const styles =
    type === "danger"
      ? "border-danger-200 bg-danger-50 text-danger-700"
      : type === "success"
      ? "border-success-200 bg-success-50 text-success-700"
      : type === "warning"
      ? "border-warning-200 bg-warning-focus text-warning-main"
      : "border-gray-200 bg-gray-50 text-gray-700";

  return (
    <div className={`border radius-12 p-12 ${styles}`} style={{ marginBottom: 12 }}>
      {children}
    </div>
  );
}

function Card({ title, subtitle, children, right }) {
  return (
    <div className="card border radius-16 mb-16">
      <div className="card-body p-16">
        <div className="d-flex align-items-start justify-content-between gap-12 flex-wrap mb-12">
          <div>
            <div className="fw-semibold text-black">{title}</div>
            {subtitle ? <div className="text-secondary-light" style={{ fontSize: 13 }}>{subtitle}</div> : null}
          </div>
          {right ? <div>{right}</div> : null}
        </div>
        {children}
      </div>
    </div>
  );
}

function StepPill({ idx, title, active, done }) {
  const base = "d-flex align-items-center gap-8";
  const circleCls = done
    ? "bg-success-main text-white"
    : active
    ? "bg-primary-600 text-white"
    : "bg-gray-100 text-gray-700";
  const textCls = active ? "text-black" : "text-secondary-light";
  return (
    <div className={base}>
      <div
        className={`radius-16 d-flex align-items-center justify-content-center ${circleCls}`}
        style={{ width: 28, height: 28, fontWeight: 700, fontSize: 13 }}
      >
        {done ? "✓" : idx}
      </div>
      <div className={`fw-semibold ${textCls}`} style={{ fontSize: 13 }}>
        {title}
      </div>
    </div>
  );
}

export default function NewOrganizationPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [orgId, setOrgId] = useState(null);

  // Load organization types from DB seeder table via API
  const [orgTypes, setOrgTypes] = useState([]);
  const [typesLoading, setTypesLoading] = useState(true);
  const [typesError, setTypesError] = useState("");

  const [basic, setBasic] = useState({
    name: "",
    orgTypeCode: "",
    supportPhone: "",
    supportEmail: "",
    whatsappNumber: "",
    alternatePhone: "",
    addressText: "",
  });

  const [location, setLocation] = useState({});

  const [legal, setLegal] = useState({
    registrationType: "PROPRIETORSHIP",
    tradeLicenseNumber: "",
    tradeLicenseIssueDate: "",
    tradeLicenseExpiryDate: "",
    issuingAuthority: "",
    tinNumber: "",
    binNumber: "",
    officialEmail: "",
    officialPhone: "",
    website: "",
    facebookPage: "",
    bankAccountName: "",
    bankAccountNumber: "",
    bankName: "",
    bankBranchName: "",
    routingNumber: "",
    payoutBkash: "",
    payoutNagad: "",
    payoutRocket: "",
  });

  const [directors, setDirectors] = useState([{ name: "", role: "Owner", mobile: "", email: "" }]);

  const [typeSpecific, setTypeSpecific] = useState({});

  const [docs, setDocs] = useState({
    TRADE_LICENSE: null,
  });

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});

  useEffect(() => {
    (async () => {
      setTypesLoading(true);
      setTypesError("");
      try {
        // Organization types are public master data
        const rows = await apiGet("/api/v1/meta/organization-types");
        const list = Array.isArray(rows) ? rows : [];
        setOrgTypes(list);
        if (!basic.orgTypeCode && list.length) {
          setBasic((p) => ({ ...p, orgTypeCode: list[0].code }));
        }
      } catch (e) {
        setTypesError(e?.message || "Failed to load organization types");
      } finally {
        setTypesLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const canNext = useMemo(() => {
    if (step === 1) return !!basic.name && !!basic.supportPhone && !!basic.orgTypeCode && (!!location?.bdAreaId || !!location?.dhakaAreaId) && !!(location?.fullPathText || location?.text);
    if (step === 2) return !!legal.tradeLicenseNumber;
    if (step === 3) return !!docs.TRADE_LICENSE;
    return true;
  }, [step, basic, legal, docs, location]);

  function validateEmail(email) {
    if (!email) return null;
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email) ? null : "Invalid email format";
  }

  function validatePhone(phone) {
    if (!phone) return null;
    const re = /^[0-9]{10,15}$/;
    return re.test(phone.replace(/[\s\-+()]/g, '')) ? null : "Invalid phone number (10-15 digits)";
  }

  function validateURL(url) {
    if (!url) return null;
    try {
      new URL(url);
      return null;
    } catch {
      return "Invalid URL format";
    }
  }

  function validateDateRange(issueDate, expiryDate) {
    if (!issueDate || !expiryDate) return null;
    const issue = new Date(issueDate);
    const expiry = new Date(expiryDate);
    return expiry > issue ? null : "Expiry date must be after issue date";
  }

  function setBasicField(k, v) {
    setBasic((p) => ({ ...p, [k]: v }));
    // Clear error when user types
    if (fieldErrors[k]) {
      setFieldErrors((prev) => {
        const next = { ...prev };
        delete next[k];
        return next;
      });
    }
    // Validate on change
    if (k === "supportEmail" && v) {
      const err = validateEmail(v);
      if (err) setFieldErrors((prev) => ({ ...prev, [k]: err }));
    }
    if ((k === "supportPhone" || k === "whatsappNumber" || k === "alternatePhone") && v) {
      const err = validatePhone(v);
      if (err) setFieldErrors((prev) => ({ ...prev, [k]: err }));
    }
  }

  function setLegalField(k, v) {
    setLegal((p) => ({ ...p, [k]: v }));
    // Clear error when user types
    if (fieldErrors[k]) {
      setFieldErrors((prev) => {
        const next = { ...prev };
        delete next[k];
        return next;
      });
    }
    // Validate on change
    if (k === "officialEmail" && v) {
      const err = validateEmail(v);
      if (err) setFieldErrors((prev) => ({ ...prev, [k]: err }));
    }
    if (k === "officialPhone" && v) {
      const err = validatePhone(v);
      if (err) setFieldErrors((prev) => ({ ...prev, [k]: err }));
    }
    if ((k === "website" || k === "facebookPage") && v) {
      const err = validateURL(v);
      if (err) setFieldErrors((prev) => ({ ...prev, [k]: err }));
    }
    // Validate date range
    if (k === "tradeLicenseIssueDate" || k === "tradeLicenseExpiryDate") {
      const err = validateDateRange(legal.tradeLicenseIssueDate || (k === "tradeLicenseIssueDate" ? v : ""), legal.tradeLicenseExpiryDate || (k === "tradeLicenseExpiryDate" ? v : ""));
      if (err) setFieldErrors((prev) => ({ ...prev, tradeLicenseDateRange: err }));
      else {
        setFieldErrors((prev) => {
          const next = { ...prev };
          delete next.tradeLicenseDateRange;
          return next;
        });
      }
    }
    if ((k === "payoutBkash" || k === "payoutNagad" || k === "payoutRocket") && v) {
      const err = validatePhone(v);
      if (err) setFieldErrors((prev) => ({ ...prev, [k]: err }));
    }
  }

  async function ensureOrgCreated() {
    if (orgId) return orgId;
    const created = await apiPost("/api/v1/owner/organizations", {
      name: basic.name,
      supportPhone: basic.supportPhone,
      // Keep schema-safe: store extra fields under addressJson for backward compatibility
      cityCorporationId: location?.cityCorporationId || null,
      dhakaAreaId: location?.dhakaAreaId || null,
      bdAreaId: location?.bdAreaId || null,
      fullPathText: location?.fullPathText || location?.text || null,
      addressJson: {
        text: basic.addressText || "",
        orgTypeCode: basic.orgTypeCode,
        locationKind: location?.kind || null,
        cityCorporationId: location?.cityCorporationId || null,
        cityCorporationCode: location?.cityCorporationCode || null,
        dhakaAreaId: location?.dhakaAreaId || null,
        bdAreaId: location?.bdAreaId || null,
        fullPathText: location?.fullPathText || location?.text || null,
        latitude: location?.latitude || null,
        longitude: location?.longitude || null,
        whatsappNumber: basic.whatsappNumber || null,
        alternatePhone: basic.alternatePhone || null,
        typeSpecific: typeSpecific || {},
      },
      supportEmail: basic.supportEmail || null,
    });
    setOrgId(created.id);
    return created.id;
  }

  async function saveDraft() {
    setError("");
    setBusy(true);
    try {
      const id = await ensureOrgCreated();
      await apiPost(`/api/v1/owner/organizations/${id}/legal-profile/save-draft`, {
        organizationName: basic.name,
        registrationType: legal.registrationType,
        tradeLicenseNumber: legal.tradeLicenseNumber,
        tradeLicenseIssueDate: legal.tradeLicenseIssueDate || null,
        tradeLicenseExpiryDate: legal.tradeLicenseExpiryDate || null,
        issuingAuthority: legal.issuingAuthority,
        tinNumber: legal.tinNumber,
        binNumber: legal.binNumber,
        officialEmail: legal.officialEmail,
        officialPhone: legal.officialPhone || basic.supportPhone,
        website: legal.website,
        facebookPage: legal.facebookPage,
        bankAccountName: legal.bankAccountName || null,
        bankAccountNumber: legal.bankAccountNumber || null,
        bankName: legal.bankName || null,
        bankBranchName: legal.bankBranchName || null,
        routingNumber: legal.routingNumber || null,
        payoutBkash: legal.payoutBkash || null,
        payoutNagad: legal.payoutNagad || null,
        payoutRocket: legal.payoutRocket || null,
      });
      await apiPost(`/api/v1/owner/organizations/${id}/legal-profile/save-directors`, { directors });
    } catch (e) {
      setError(e.message || "Failed to save draft");
    } finally {
      setBusy(false);
    }
  }

  async function handleTradeLicenseUpload(file) {
    setError("");
    setBusy(true);
    try {
      const id = await ensureOrgCreated();
      const fileId = await uploadMedia(file);
      await apiPost(`/api/v1/owner/organizations/${id}/legal-profile/add-document`, {
        type: "TRADE_LICENSE",
        fileId,
        mediaId: fileId,
      });
      setDocs({ TRADE_LICENSE: { fileName: file.name, fileId } });
    } catch (e) {
      setError(e.message || "Upload failed");
    } finally {
      setBusy(false);
    }
  }

  async function submit() {
    setError("");
    setBusy(true);
    try {
      const id = await ensureOrgCreated();
      await saveDraft();
      await apiPost(`/api/v1/owner/organizations/${id}/legal-profile/submit`, {});
      router.push("/owner/organizations");
    } catch (e) {
      setError(e.message || "Submit failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container-fluid" >
      <div className="d-flex align-items-start justify-content-between gap-12 flex-wrap mt-12 mb-12">
        <div>
          <div className="d-flex align-items-center gap-8 flex-wrap">
            <h4 className="mb-0">Organization Registration</h4>
            {orgId ? (
              <span className="badge bg-primary-50 text-primary-600 radius-16 px-12 py-6 fw-semibold">
                Draft ID: {orgId}
              </span>
            ) : null}
          </div>
          <div className="text-secondary-light" style={{ fontSize: 13 }}>
            Trade license verification is required before publishing branches.
          </div>
        </div>

        <div className="d-flex gap-8 flex-wrap">
          <button className="btn btn-outline-secondary" disabled={busy} onClick={saveDraft}>
            Save Draft
          </button>
          {step < 4 ? (
            <button
              className="btn btn-primary"
              disabled={busy || !canNext}
              onClick={() => setStep((s) => Math.min(4, s + 1))}
            >
              Next
            </button>
          ) : (
            <button className="btn btn-success" disabled={busy} onClick={submit}>
              Submit for Verification
            </button>
          )}
        </div>
      </div>

      {error ? <Alert type="danger">{error}</Alert> : null}

      <div className="card border radius-16 mb-16">
        <div className="card-body p-16">
          <div className="d-flex align-items-center justify-content-between flex-wrap gap-12">
            <div className="text-secondary-light" style={{ fontSize: 13 }}>
              Step {step} of 4
            </div>
            <div className="d-flex align-items-center gap-16 flex-wrap">
              <StepPill idx={1} title="Business" active={step === 1} done={step > 1} />
              <StepPill idx={2} title="Legal" active={step === 2} done={step > 2} />
              <StepPill idx={3} title="Documents" active={step === 3} done={step > 3} />
              <StepPill idx={4} title="Review" active={step === 4} done={false} />
            </div>
          </div>

          <div className="progress mt-12" style={{ height: 8 }}>
            <div
              className="progress-bar"
              role="progressbar"
              style={{ width: `${(step / 4) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {step === 1 ? (
        <Card title="Business Information" subtitle="Basic organization info">
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Organization Name *</label>
              <input className="form-control" value={basic.name} onChange={(e) => setBasicField("name", e.target.value)} placeholder="e.g., Community Pet Clinic" />
            </div>
            <div className="col-md-6">
              <label className="form-label">Organization Type *</label>
              <select
                className="form-select"
                value={basic.orgTypeCode}
                onChange={(e) => setBasicField("orgTypeCode", e.target.value)}
                disabled={typesLoading || !!typesError}
              >
                {typesLoading ? <option value="">Loading...</option> : null}
                {!typesLoading && !typesError && orgTypes.length === 0 ? <option value="">No types found</option> : null}
                {!typesLoading && !typesError
                  ? orgTypes.map((t) => (
                      <option key={t.code} value={t.code}>
                        {t.nameEn || t.label}
                      </option>
                    ))
                  : null}
              </select>
              {typesError ? <div className="text-danger mt-1" style={{ fontSize: 12 }}>{typesError}</div> : null}
              {!typesLoading && !typesError ? (
                <div className="text-muted" style={{ fontSize: 12 }}>Loaded from seeded types in the database.</div>
              ) : null}
            </div>
            <div className="col-md-6">
              <label className="form-label">Support Phone *</label>
              <input className="form-control" value={basic.supportPhone} onChange={(e) => setBasicField("supportPhone", e.target.value)} placeholder="e.g., 017XXXXXXXX" />
            </div>
            <div className="col-md-6">
              <label className="form-label">Support Email</label>
              <input type="email" className={`form-control ${fieldErrors.supportEmail ? "is-invalid" : ""}`} value={basic.supportEmail} onChange={(e) => setBasicField("supportEmail", e.target.value)} placeholder="e.g., support@example.com" />
              {fieldErrors.supportEmail && <div className="invalid-feedback">{fieldErrors.supportEmail}</div>}
            </div>
            <div className="col-md-4">
              <label className="form-label">WhatsApp Number</label>
              <input className={`form-control ${fieldErrors.whatsappNumber ? "is-invalid" : ""}`} value={basic.whatsappNumber} onChange={(e) => setBasicField("whatsappNumber", e.target.value)} placeholder="e.g., 017XXXXXXXX" />
              {fieldErrors.whatsappNumber && <div className="invalid-feedback">{fieldErrors.whatsappNumber}</div>}
            </div>
            <div className="col-md-4">
              <label className="form-label">Alternate Phone</label>
              <input className={`form-control ${fieldErrors.alternatePhone ? "is-invalid" : ""}`} value={basic.alternatePhone} onChange={(e) => setBasicField("alternatePhone", e.target.value)} placeholder="e.g., 019XXXXXXXX" />
              {fieldErrors.alternatePhone && <div className="invalid-feedback">{fieldErrors.alternatePhone}</div>}
            </div>

            <div className="col-12 mt-3">
              <ImprovedLocationPicker
                value={location}
                onChange={(next) => setLocation(next || {})}
                title="Business Location (Bangladesh / Dhaka City)"
              />
            </div>
            <div className="col-12">
              <label className="form-label">Office Address</label>
              <textarea className="form-control" rows={3} value={basic.addressText} onChange={(e) => setBasicField("addressText", e.target.value)} placeholder="House/Road, Area, District, Division" />
            </div>

            {/* Type-Specific Fields */}
            {basic.orgTypeCode && (
              <div className="col-12 mt-4">
                <div className="border-top pt-3">
                  <h6 className="fw-semibold mb-3">
                    {basic.orgTypeCode === "CLINIC" ? "Clinic Information" :
                     basic.orgTypeCode === "PET_SHOP" ? "Pet Shop Information" :
                     basic.orgTypeCode === "ONLINE_HUB" ? "Online Hub Information" :
                     "Additional Information"}
                  </h6>
                  {basic.orgTypeCode === "CLINIC" ? (
                    <div className="row g-3">
                      <div className="col-md-6">
                        <label className="form-label">Vet License Number</label>
                        <input className="form-control" value={typeSpecific.vetLicenseNumber || ""} onChange={(e) => setTypeSpecific({...typeSpecific, vetLicenseNumber: e.target.value})} placeholder="Veterinary license number" />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Emergency Contact</label>
                        <input className="form-control" value={typeSpecific.emergencyContact || ""} onChange={(e) => setTypeSpecific({...typeSpecific, emergencyContact: e.target.value})} placeholder="Emergency contact number" />
                      </div>
                      <div className="col-md-12">
                        <label className="form-label">Specializations</label>
                        <input className="form-control" value={typeSpecific.specializations || ""} onChange={(e) => setTypeSpecific({...typeSpecific, specializations: e.target.value})} placeholder="e.g., Surgery, Vaccination, Grooming" />
                      </div>
                      <div className="col-md-12">
                        <label className="form-label">Services Offered</label>
                        <textarea className="form-control" rows={3} value={typeSpecific.services || ""} onChange={(e) => setTypeSpecific({...typeSpecific, services: e.target.value})} placeholder="List services offered (one per line)" />
                      </div>
                    </div>
                  ) : basic.orgTypeCode === "PET_SHOP" ? (
                    <div className="row g-3">
                      <div className="col-md-6">
                        <label className="form-label">Store Hours</label>
                        <input className="form-control" value={typeSpecific.storeHours || ""} onChange={(e) => setTypeSpecific({...typeSpecific, storeHours: e.target.value})} placeholder="e.g., 9 AM - 9 PM" />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Delivery Available</label>
                        <select className="form-select" value={typeSpecific.deliveryAvailable || ""} onChange={(e) => setTypeSpecific({...typeSpecific, deliveryAvailable: e.target.value})}>
                          <option value="">Select...</option>
                          <option value="yes">Yes</option>
                          <option value="no">No</option>
                        </select>
                      </div>
                      <div className="col-md-12">
                        <label className="form-label">Product Categories Focus</label>
                        <input className="form-control" value={typeSpecific.productCategories || ""} onChange={(e) => setTypeSpecific({...typeSpecific, productCategories: e.target.value})} placeholder="e.g., Food, Toys, Accessories" />
                      </div>
                      <div className="col-md-12">
                        <label className="form-label">Online Store URL</label>
                        <input className="form-control" value={typeSpecific.onlineStoreUrl || ""} onChange={(e) => setTypeSpecific({...typeSpecific, onlineStoreUrl: e.target.value})} placeholder="e.g., https://shop.example.com" />
                      </div>
                    </div>
                  ) : basic.orgTypeCode === "ONLINE_HUB" ? (
                    <div className="row g-3">
                      <div className="col-md-6">
                        <label className="form-label">Platform Website</label>
                        <input className="form-control" value={typeSpecific.platformUrl || ""} onChange={(e) => setTypeSpecific({...typeSpecific, platformUrl: e.target.value})} placeholder="Main platform URL" />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Social Media Links</label>
                        <input className="form-control" value={typeSpecific.socialMedia || ""} onChange={(e) => setTypeSpecific({...typeSpecific, socialMedia: e.target.value})} placeholder="Comma-separated URLs" />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Delivery Coverage Areas</label>
                        <input className="form-control" value={typeSpecific.deliveryCoverage || ""} onChange={(e) => setTypeSpecific({...typeSpecific, deliveryCoverage: e.target.value})} placeholder="e.g., Dhaka, Chittagong" />
                      </div>
                      <div className="col-md-3">
                        <label className="form-label">Minimum Order Value (BDT)</label>
                        <input type="number" className="form-control" value={typeSpecific.minOrderValue || ""} onChange={(e) => setTypeSpecific({...typeSpecific, minOrderValue: e.target.value})} placeholder="0" />
                      </div>
                      <div className="col-md-3">
                        <label className="form-label">Delivery Charge (BDT)</label>
                        <input type="number" className="form-control" value={typeSpecific.deliveryCharge || ""} onChange={(e) => setTypeSpecific({...typeSpecific, deliveryCharge: e.target.value})} placeholder="0" />
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>
            )}
          </div>
        </Card>
      ) : null}

      {step === 2 ? (
        <Card title="Legal & Tax Information" subtitle="Trade license is required">
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Registration Type *</label>
              <select className="form-select" value={legal.registrationType} onChange={(e) => setLegalField("registrationType", e.target.value)}>
                <option value="PROPRIETORSHIP">Proprietorship</option>
                <option value="PARTNERSHIP">Partnership</option>
                <option value="LIMITED_COMPANY">Limited Company</option>
                <option value="NGO">NGO</option>
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label">Trade License Number *</label>
              <input className="form-control" value={legal.tradeLicenseNumber} onChange={(e) => setLegalField("tradeLicenseNumber", e.target.value)} placeholder="e.g., TR-123456" />
            </div>
            <div className="col-md-3">
              <label className="form-label">Issue Date</label>
              <input type="date" className={`form-control ${fieldErrors.tradeLicenseDateRange ? "is-invalid" : ""}`} value={legal.tradeLicenseIssueDate} onChange={(e) => setLegalField("tradeLicenseIssueDate", e.target.value)} />
              {fieldErrors.tradeLicenseDateRange && <div className="invalid-feedback">{fieldErrors.tradeLicenseDateRange}</div>}
            </div>
            <div className="col-md-3">
              <label className="form-label">Expiry Date</label>
              <input type="date" className={`form-control ${fieldErrors.tradeLicenseDateRange ? "is-invalid" : ""}`} value={legal.tradeLicenseExpiryDate} onChange={(e) => setLegalField("tradeLicenseExpiryDate", e.target.value)} />
            </div>
            <div className="col-md-6">
              <label className="form-label">Issuing Authority</label>
              <input className="form-control" value={legal.issuingAuthority} onChange={(e) => setLegalField("issuingAuthority", e.target.value)} placeholder="e.g., Dhaka City Corporation" />
            </div>
            <div className="col-md-6">
              <label className="form-label">TIN Number</label>
              <input className="form-control" value={legal.tinNumber} onChange={(e) => setLegalField("tinNumber", e.target.value)} placeholder="e.g., 1234567890" />
            </div>
            <div className="col-md-6">
              <label className="form-label">BIN Number</label>
              <input className="form-control" value={legal.binNumber} onChange={(e) => setLegalField("binNumber", e.target.value)} placeholder="e.g., 123456789-0001" />
            </div>
            <div className="col-md-6">
              <label className="form-label">Official Phone</label>
              <input className="form-control" value={legal.officialPhone} onChange={(e) => setLegalField("officialPhone", e.target.value)} placeholder="e.g., 017XXXXXXXX" />
            </div>
            <div className="col-md-6">
              <label className="form-label">Official Email</label>
              <input type="email" className="form-control" value={legal.officialEmail} onChange={(e) => setLegalField("officialEmail", e.target.value)} placeholder="e.g., office@example.com" />
            </div>
            <div className="col-md-6">
              <label className="form-label">Website</label>
              <input className="form-control" value={legal.website} onChange={(e) => setLegalField("website", e.target.value)} placeholder="e.g., https://example.com" />
            </div>
            <div className="col-md-6">
              <label className="form-label">Facebook Page</label>
              <input className="form-control" value={legal.facebookPage} onChange={(e) => setLegalField("facebookPage", e.target.value)} placeholder="e.g., https://facebook.com/yourpage" />
            </div>

            <div className="col-12 mt-4">
              <div className="border-top pt-3">
                <h6 className="fw-semibold mb-3">Bank Account Information</h6>
                <div className="row g-3">
                  <div className="col-md-6">
                    <label className="form-label">Account Name</label>
                    <input className="form-control" value={legal.bankAccountName} onChange={(e) => setLegalField("bankAccountName", e.target.value)} placeholder="Account holder name" />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Account Number</label>
                    <input className="form-control" value={legal.bankAccountNumber} onChange={(e) => setLegalField("bankAccountNumber", e.target.value)} placeholder="Bank account number" />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Bank Name</label>
                    <input className="form-control" value={legal.bankName} onChange={(e) => setLegalField("bankName", e.target.value)} placeholder="e.g., Sonali Bank" />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Branch Name</label>
                    <input className="form-control" value={legal.bankBranchName} onChange={(e) => setLegalField("bankBranchName", e.target.value)} placeholder="Branch name" />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Routing Number</label>
                    <input className="form-control" value={legal.routingNumber} onChange={(e) => setLegalField("routingNumber", e.target.value)} placeholder="Bank routing number" />
                  </div>
                </div>
              </div>
            </div>

            <div className="col-12 mt-4">
              <div className="border-top pt-3">
                <h6 className="fw-semibold mb-3">Payment/Payout Methods</h6>
                <div className="row g-3">
                  <div className="col-md-4">
                    <label className="form-label">bKash Number</label>
                    <input className={`form-control ${fieldErrors.payoutBkash ? "is-invalid" : ""}`} value={legal.payoutBkash} onChange={(e) => setLegalField("payoutBkash", e.target.value)} placeholder="e.g., 017XXXXXXXX" />
                    {fieldErrors.payoutBkash && <div className="invalid-feedback">{fieldErrors.payoutBkash}</div>}
                  </div>
                  <div className="col-md-4">
                    <label className="form-label">Nagad Number</label>
                    <input className={`form-control ${fieldErrors.payoutNagad ? "is-invalid" : ""}`} value={legal.payoutNagad} onChange={(e) => setLegalField("payoutNagad", e.target.value)} placeholder="e.g., 017XXXXXXXX" />
                    {fieldErrors.payoutNagad && <div className="invalid-feedback">{fieldErrors.payoutNagad}</div>}
                  </div>
                  <div className="col-md-4">
                    <label className="form-label">Rocket Number</label>
                    <input className={`form-control ${fieldErrors.payoutRocket ? "is-invalid" : ""}`} value={legal.payoutRocket} onChange={(e) => setLegalField("payoutRocket", e.target.value)} placeholder="e.g., 017XXXXXXXX" />
                    {fieldErrors.payoutRocket && <div className="invalid-feedback">{fieldErrors.payoutRocket}</div>}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      ) : null}

      {step === 3 ? (
        <Card title="Documents & Directors" subtitle="Upload trade license and add directors/partners (if applicable)">
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Trade License Document *</label>
              <input type="file" className="form-control" onChange={(e) => e.target.files?.[0] && handleTradeLicenseUpload(e.target.files[0])} />
              <div className="text-muted mt-1" style={{ fontSize: 12 }}>
                {docs.TRADE_LICENSE ? `Uploaded: ${docs.TRADE_LICENSE.fileName}` : "Not uploaded"}
              </div>
            </div>

            <div className="col-12">
              <div className="d-flex align-items-center justify-content-between">
                <div>
                  <div className="fw-semibold">Directors / Partners</div>
                  <div className="text-muted" style={{ fontSize: 12 }}>Add at least one responsible person</div>
                </div>
                <button
                  type="button"
                  className="btn btn-outline-primary btn-sm"
                  onClick={() => setDirectors((p) => [...p, { name: "", role: "Director", mobile: "", email: "" }])}
                >
                  Add Person
                </button>
              </div>

              <div className="mt-2">
                {directors.map((d, idx) => (
                  <div className="border rounded p-3 mb-2" key={idx}>
                    <div className="row g-2">
                      <div className="col-md-4">
                        <label className="form-label">Name *</label>
                        <input className="form-control" value={d.name} onChange={(e) => {
                          const v = e.target.value;
                          setDirectors((p) => p.map((x, i) => i === idx ? { ...x, name: v } : x));
                        }} />
                      </div>
                      <div className="col-md-3">
                        <label className="form-label">Role</label>
                        <input className="form-control" value={d.role} onChange={(e) => {
                          const v = e.target.value;
                          setDirectors((p) => p.map((x, i) => i === idx ? { ...x, role: v } : x));
                        }} />
                      </div>
                      <div className="col-md-3">
                        <label className="form-label">Mobile</label>
                        <input className="form-control" value={d.mobile} onChange={(e) => {
                          const v = e.target.value;
                          setDirectors((p) => p.map((x, i) => i === idx ? { ...x, mobile: v } : x));
                        }} />
                      </div>
                      <div className="col-md-2">
                        <label className="form-label">Email</label>
                        <input className="form-control" value={d.email} onChange={(e) => {
                          const v = e.target.value;
                          setDirectors((p) => p.map((x, i) => i === idx ? { ...x, email: v } : x));
                        }} />
                      </div>
                    </div>
                    {directors.length > 1 ? (
                      <div className="text-end mt-2">
                        <button type="button" className="btn btn-outline-danger btn-sm" onClick={() => setDirectors((p) => p.filter((_, i) => i !== idx))}>
                          Remove
                        </button>
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>
      ) : null}

      {step === 4 ? (
        <Card title="Review & Submit" subtitle="Confirm information before submitting">
          <div className="row g-3">
            <div className="col-12">
              <h6 className="fw-semibold mb-3">Business Information</h6>
            </div>
            <div className="col-md-6">
              <div className="text-muted" style={{ fontSize: 12 }}>Organization Name</div>
              <div className="fw-semibold">{basic.name || "-"}</div>
            </div>
            <div className="col-md-6">
              <div className="text-muted" style={{ fontSize: 12 }}>Organization Type</div>
              <div className="fw-semibold">
                {basic.orgTypeCode
                  ? (orgTypes.find((x) => x.code === basic.orgTypeCode)?.nameEn || basic.orgTypeCode)
                  : "-"}
              </div>
            </div>
            <div className="col-md-4">
              <div className="text-muted" style={{ fontSize: 12 }}>Support Phone</div>
              <div className="fw-semibold">{basic.supportPhone || "-"}</div>
            </div>
            <div className="col-md-4">
              <div className="text-muted" style={{ fontSize: 12 }}>Support Email</div>
              <div className="fw-semibold">{basic.supportEmail || "-"}</div>
            </div>
            <div className="col-md-4">
              <div className="text-muted" style={{ fontSize: 12 }}>WhatsApp Number</div>
              <div className="fw-semibold">{basic.whatsappNumber || "-"}</div>
            </div>
            <div className="col-12">
              <div className="text-muted" style={{ fontSize: 12 }}>Location</div>
              <div className="fw-semibold">{location?.fullPathText || location?.text || "-"}</div>
            </div>

            <div className="col-12 mt-4">
              <h6 className="fw-semibold mb-3">Legal & Tax Information</h6>
            </div>
            <div className="col-md-6">
              <div className="text-muted" style={{ fontSize: 12 }}>Registration Type</div>
              <div className="fw-semibold">{legal.registrationType}</div>
            </div>
            <div className="col-md-6">
              <div className="text-muted" style={{ fontSize: 12 }}>Trade License Number</div>
              <div className="fw-semibold">{legal.tradeLicenseNumber || "-"}</div>
            </div>
            {legal.bankAccountName && (
              <div className="col-12 mt-3">
                <div className="text-muted" style={{ fontSize: 12 }}>Bank Account</div>
                <div className="fw-semibold">{legal.bankAccountName} - {legal.bankName}</div>
              </div>
            )}
            {(legal.payoutBkash || legal.payoutNagad || legal.payoutRocket) && (
              <div className="col-12 mt-3">
                <div className="text-muted" style={{ fontSize: 12 }}>Payout Methods</div>
                <div className="fw-semibold">
                  {[legal.payoutBkash && `bKash: ${legal.payoutBkash}`, legal.payoutNagad && `Nagad: ${legal.payoutNagad}`, legal.payoutRocket && `Rocket: ${legal.payoutRocket}`].filter(Boolean).join(", ") || "-"}
                </div>
              </div>
            )}

            <div className="col-12 mt-4">
              <div className="text-muted" style={{ fontSize: 12 }}>Trade License Document</div>
              <div className="fw-semibold">{docs.TRADE_LICENSE ? "Uploaded" : "Missing"}</div>
            </div>
          </div>
          <div className="alert alert-warning mt-3 mb-0">
            After submission, the organization status becomes <strong>Pending Review</strong> until approved by Admin.
          </div>
        </Card>
      ) : null}

      <div className="d-flex justify-content-between mt-3">
        <button className="btn btn-outline-secondary" disabled={busy || step === 1} onClick={() => setStep((s) => Math.max(1, s - 1))}>Back</button>
        <div className="d-flex gap-8 flex-wrap">
          <button className="btn btn-outline-secondary" disabled={busy} onClick={saveDraft}>Save Draft</button>
          {step < 4 ? (
            <button className="btn btn-primary" disabled={busy || !canNext} onClick={() => setStep((s) => Math.min(4, s + 1))}>Next</button>
          ) : (
            <button className="btn btn-success" disabled={busy} onClick={submit}>Submit for Verification</button>
          )}
        </div>
      </div>
    </div>
  );
}
