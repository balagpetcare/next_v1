"use client";

import { useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import MasterLayout from "@/src/masterLayout/MasterLayout";
import NotificationContainer from "./_components/Notification";

// Base API host (no trailing slash). Example: http://localhost:3000
const API_BASE = String(process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3000").replace(/\/+$/, "");

export default function OwnerLayout({ children }) {
  const pathname = usePathname();
  const router = useRouter();

  // IMPORTANT: Don't return early before hooks run; otherwise hook order can change
  // between renders and React will throw (Rules of Hooks).
  const isAuthRoute =
    pathname?.startsWith("/owner/login") || 
    pathname?.startsWith("/owner/logout") || 
    pathname?.startsWith("/owner/register") ||
    pathname?.startsWith("/owner/regester");

  const isKycRoute = pathname?.startsWith("/owner/kyc");
  const isBranchTeamRoute = /^\/owner\/branches\/[^\/]+\/team(\/|$)/.test(String(pathname || ""));
  const isBranchDashboardRoute = /^\/owner\/branches\/\d+(\/|$)/.test(String(pathname || ""));

  // Auth routes must be standalone (no sidebar/topbar)
  // NOTE: We can't early-return before hooks run; render branch happens at the end.

  // Mandatory KYC gate:
  // - allow the KYC page itself
  // - for all other owner pages, redirect to /owner/kyc until status is SUBMITTED/VERIFIED
  useEffect(() => {
    let cancelled = false;
    async function checkKyc() {
      try {
        // Skip gate checks on auth routes and on the KYC page itself.
        if (!pathname || isAuthRoute || pathname.startsWith("/owner/kyc")) return;

        const res = await fetch(`${API_BASE}/api/v1/owner/kyc`, {
          method: "GET",
          credentials: "include",
          headers: { Accept: "application/json" },
        });

        const j = await res.json().catch(() => null);
        const kyc = j?.success ? j.data : j;
        const status = String(kyc?.verificationStatus || "UNSUBMITTED").toUpperCase();
        const ok = status === "SUBMITTED" || status === "VERIFIED";

        if (!cancelled && !ok && !isAuthRoute && !isKycRoute && !isBranchTeamRoute && !isBranchDashboardRoute) {
          router.replace("/owner/kyc");
        }
      } catch {
        if (!cancelled) router.replace("/owner/kyc");
      }
    }
    checkKyc();
    return () => {
      cancelled = true;
    };
  }, [pathname, router, isAuthRoute, isKycRoute, isBranchTeamRoute, isBranchDashboardRoute]);

  if (isAuthRoute) return <>{children}</>;

  return (
    <>
      <NotificationContainer />
      <MasterLayout>{children}</MasterLayout>
    </>
  );
}
