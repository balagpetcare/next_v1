"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ownerGet } from "@/app/owner/_lib/ownerApi";

export default function NotificationBadge() {
  const [count, setCount] = useState(0);
  const [loading, setLoading] = useState(true);

  async function loadNotificationCount() {
    try {
      const res = await ownerGet("/api/v1/me/notifications");
      if (res?.success && Array.isArray(res.data)) {
        // Count only unread STAFF_INVITE notifications
        const staffInviteCount = res.data.filter((n) => n.type === "STAFF_INVITE" && !n.readAt).length;
        setCount(staffInviteCount);
      }
    } catch (error) {
      console.error("Failed to load notification count:", error);
      setCount(0);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadNotificationCount();
    // Refresh every 30 seconds
    const interval = setInterval(loadNotificationCount, 30000);
    return () => clearInterval(interval);
  }, []);

  if (loading || count === 0) {
    return null;
  }

  return (
    <Link
      href="/owner/dashboard"
      className="position-relative d-flex align-items-center justify-content-center"
      style={{ textDecoration: "none" }}
      title={`${count} unread staff invitation${count !== 1 ? "s" : ""}`}
    >
      <i className="solar:bell-outline" style={{ fontSize: "20px", color: "var(--bs-body-color)" }} />
      <span
        className="badge bg-danger position-absolute"
        style={{
          top: "-4px",
          right: "-4px",
          fontSize: "10px",
          minWidth: "18px",
          height: "18px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "0 4px",
        }}
      >
        {count > 99 ? "99+" : count}
      </span>
    </Link>
  );
}
