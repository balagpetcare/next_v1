"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ownerGet, ownerPost } from "@/app/owner/_lib/ownerApi";
import StatusBadge from "@/app/owner/_components/StatusBadge";

function formatDate(dateString) {
  if (!dateString) return "—";
  return new Date(dateString).toLocaleDateString("en-BD", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function TransfersPage() {
  const [transfers, setTransfers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    loadTransfers();
  }, []);

  const loadTransfers = async () => {
    try {
      setLoading(true);
      setError("");
      const res = await ownerGet("/api/v1/transfers").catch(() => ({ success: false, data: [] }));
      const items = res?.data?.items || res?.data || res || [];
      setTransfers(Array.isArray(items) ? items : []);
    } catch (error: any) {
      setError(error?.message || "Failed to load transfers");
      console.error("Load transfers error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async (transferId: number) => {
    if (!confirm("Send this transfer?")) return;
    try {
      await ownerPost(`/api/v1/transfers/${transferId}/send`, {});
      alert("Transfer sent successfully");
      loadTransfers();
    } catch (error: any) {
      alert(error?.message || "Failed to send transfer");
    }
  };

  const handleReceive = async (transferId: number) => {
    if (!confirm("Mark this transfer as received?")) return;
    try {
      await ownerPost(`/api/v1/transfers/${transferId}/receive`, { items: [] });
      alert("Transfer received successfully");
      loadTransfers();
    } catch (error: any) {
      alert(error?.message || "Failed to receive transfer");
    }
  };

  return (
    <div className="container py-3">
      <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-4">
        <div>
          <h2 className="mb-1">Stock Transfers</h2>
          <div className="text-secondary">Manage stock transfers between branches</div>
        </div>
        <button className="btn btn-primary" onClick={() => (window.location.href = "/owner/transfers/new")}>
          <i className="solar:add-circle-outline me-1" />
          Create Transfer
        </button>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <div className="card radius-12">
        <div className="card-body p-24">
          {loading ? (
            <div className="text-center text-secondary py-4">Loading transfers...</div>
          ) : transfers.length === 0 ? (
            <div className="text-center text-secondary py-4">No transfers found</div>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover align-middle">
                <thead>
                  <tr>
                    <th>Transfer ID</th>
                    <th>From Branch</th>
                    <th>To Branch</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th style={{ width: 150 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {transfers.map((transfer) => (
                    <tr key={transfer.id}>
                      <td className="fw-semibold">#{transfer.id}</td>
                      <td>{transfer.fromLocation?.name || transfer.fromBranch?.name || "—"}</td>
                      <td>{transfer.toLocation?.name || transfer.toBranch?.name || "—"}</td>
                      <td>
                        <StatusBadge status={transfer.status || "DRAFT"} />
                      </td>
                      <td className="text-muted small">{formatDate(transfer.createdAt)}</td>
                      <td className="text-end">
                        <div className="d-flex gap-2 justify-content-end">
                          {transfer.status === "DRAFT" && (
                            <button
                              className="btn btn-outline-primary btn-sm"
                              onClick={() => handleSend(transfer.id)}
                            >
                              Send
                            </button>
                          )}
                          {transfer.status === "SENT" && (
                            <button
                              className="btn btn-outline-success btn-sm"
                              onClick={() => handleReceive(transfer.id)}
                            >
                              Receive
                            </button>
                          )}
                          <Link href={`/owner/transfers/${transfer.id}`} className="btn btn-outline-secondary btn-sm">
                            View
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
