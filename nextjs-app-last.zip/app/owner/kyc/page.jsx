"use client";

import { useEffect, useMemo, useState } from "react";
import { apiGet, apiPut, apiPost } from "../../../lib/api";

/**
 * ✅ WowDash Crop/Edit Component
 * If you have the cropping upload card component, import it here.
 * Example (adjust to your project):
 *   import ImageUploadCard from "../../../components/common/ImageUploadCard";
 */
// import ImageUploadCard from "../../../components/common/ImageUploadCard";

const REQUIRED = [
  { type: "NID_FRONT", label: "NID Front", hint: "Front side of NID (clear & readable)" },
  { type: "NID_BACK", label: "NID Back", hint: "Back side of NID (clear & readable)" },
  { type: "SELFIE_WITH_NID", label: "Selfie with NID", hint: "Hold NID near face; good lighting" },
];

function normStatus(s) {
  return String(s || "UNSUBMITTED").toUpperCase();
}
function isLockedStatus(status) {
  const t = normStatus(status);
  return t === "VERIFIED" || t === "APPROVED";
}
// ✅ SUBMITTED editable too (pending but editable)
function canEdit(status) {
  const t = normStatus(status);
  return t === "UNSUBMITTED" || t === "DRAFT" || t === "SUBMITTED" || t === "REQUEST_CHANGES";
}

/**
 * ✅ Crop config (FIX)
 * The crash you saw: "Cannot read properties of undefined (reading 'config')"
 * typically happens when a cropper component expects config but receives undefined.
 * So we always provide a safe default config + per-type overrides.
 */
const DEFAULT_CROP_CONFIG = {
  aspectRatio: 1,
  minWidth: 300,
  minHeight: 300,
  allowRotate: true,
  allowZoom: true,
};

const CROP_CONFIG = {
  NID_FRONT: { aspectRatio: 1.6 },
  NID_BACK: { aspectRatio: 1.6 },
  SELFIE_WITH_NID: { aspectRatio: 1 },
};

function getCropConfig(type) {
  const t = String(type || "").toUpperCase();
  return { ...DEFAULT_CROP_CONFIG, ...(CROP_CONFIG[t] || {}) };
}

function Badge({ text }) {
  const t = normStatus(text);
  const cls =
    t === "VERIFIED" || t === "APPROVED"
      ? "bg-success-focus text-success-main"
      : t === "REJECTED" || t === "BLOCKED"
      ? "bg-danger-focus text-danger-main"
      : t === "REQUEST_CHANGES"
      ? "bg-warning-focus text-warning-main"
      : t === "SUSPENDED"
      ? "bg-dark text-white"
      : t === "UNSUBMITTED" || t === "DRAFT"
      ? "bg-gray-200 text-gray-800"
      : "bg-primary-50 text-primary-600";
  return <span className={`badge ${cls} radius-16 px-12 py-6 fw-semibold`}>{t}</span>;
}

function Alert({ type = "info", children }) {
  const styles =
    type === "danger"
      ? "border-danger-200 bg-danger-50 text-danger-700"
      : type === "success"
      ? "border-success-200 bg-success-50 text-success-700"
      : type === "warning"
      ? "border-warning-200 bg-warning-focus text-warning-main"
      : "border-gray-200 bg-gray-50 text-gray-700";

  return (
    <div className={`border radius-12 p-12 ${styles}`} style={{ marginBottom: 12 }}>
      {children}
    </div>
  );
}

function getDocUrl(doc) {
  return doc?.url || doc?.fileUrl || doc?.publicUrl || doc?.path || "";
}

function findDoc(docs, type) {
  return (docs || []).find((d) => String(d.type).toUpperCase() === String(type).toUpperCase()) || null;
}

function KycDocCard({ label, hint, type, doc, disabled, loading, uploading, onUpload }) {
  const url = getDocUrl(doc);
  const uploaded = !!url;

  return (
    <div className="card border radius-16 h-100">
      <div className="card-body p-16">
        <div className="d-flex align-items-start justify-content-between gap-12">
          <div>
            <div className="fw-semibold">{label}</div>
            <div className="text-sm text-secondary-light">{hint}</div>
          </div>

          <span className={`text-xs fw-semibold ${uploaded ? "text-success-main" : "text-danger-main"}`}>
            {uploaded ? "Uploaded" : "Missing"}
          </span>
        </div>

        <div className="mt-12">
          {/*
            ✅ If you enable your WowDash cropping card, pass SAFE config always.
            Replace below block with your component usage.
            
            <ImageUploadCard
              title={label}
              value={url}
              disabled={disabled || loading}
              // Provide both names to be compatible with different implementations
              config={getCropConfig(type)}
              cropConfig={getCropConfig(type)}
              onChange={(file) => onUpload(type, file)}
            />
          */}

          {/* ✅ Fallback uploader with preview (works immediately) */}
          <div className="border radius-12 p-12">
            {uploaded ? (
              <div className="d-flex gap-12 align-items-start flex-wrap">
                <div
                  className="border radius-12 overflow-hidden"
                  style={{
                    width: 210,
                    height: 130,
                    background: "#f8fafc",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    position: "relative",
                  }}
                >
                  <img src={url} alt={label} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>

                <div style={{ minWidth: 240, flex: 1 }}>
                  <div className="text-sm text-secondary-light mb-8">Uploaded file</div>

                  <div className="d-flex gap-10 flex-wrap">
                    <a className="btn btn-light btn-sm radius-12" href={url} target="_blank" rel="noreferrer">
                      View
                    </a>
                    <a className="btn btn-light btn-sm radius-12" href={url} download>
                      Download
                    </a>
                  </div>

                  <div className="mt-12">
                    <div className="text-sm text-secondary-light mb-8">Replace file</div>
                    <input
                      type="file"
                      className="form-control"
                      accept="image/*"
                      disabled={disabled || loading}
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (!f) return;
                        onUpload(type, f, e.target);
                      }}
                    />
                    <div className="text-xs text-secondary-light mt-8">
                      {disabled ? "Locked / not editable right now." : "You can replace before approval / when requested changes."}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <input
                  type="file"
                  className="form-control"
                  accept="image/*"
                  disabled={disabled || loading}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    onUpload(type, f, e.target);
                  }}
                />
                <div className="text-xs text-secondary-light mt-8">Upload an image file (clear & readable).</div>
              </div>
            )}

            {uploading ? <div className="text-xs text-secondary-light mt-8">Uploading...</div> : null}
          </div>
        </div>
      </div>
    </div>
  );
}

function Steps({ step, setStep, step2Enabled }) {
  return (
    <div className="card border radius-16 mb-16">
      <div className="card-body p-16">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-10">
          <div className="d-flex align-items-center gap-10 flex-wrap">
            <button
              className={`btn ${step === 1 ? "btn-primary" : "btn-light"} radius-12`}
              onClick={() => setStep(1)}
              type="button"
            >
              1 KYC Information
            </button>

            <button
              className={`btn ${step === 2 ? "btn-primary" : "btn-light"} radius-12`}
              onClick={() => {
                if (!step2Enabled) return;
                setStep(2);
              }}
              type="button"
              disabled={!step2Enabled}
            >
              2 Documents
            </button>
          </div>

          <div className="text-sm text-secondary-light">{step2Enabled ? "Step 2 unlocked" : "Save Step 1 to unlock Step 2"}</div>
        </div>
      </div>
    </div>
  );
}

export default function OwnerKycPage() {
  const [loading, setLoading] = useState(false);
  const [kyc, setKyc] = useState(null);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [uploadingType, setUploadingType] = useState(null);
  const [step, setStep] = useState(1);

  const [draft, setDraft] = useState({
    fullName: "",
    mobile: "",
    email: "",
    nidNumber: "",
  });

  async function load() {
    setErr("");
    setMsg("");
    try {
      const res = await apiGet("/api/v1/owner/kyc");
      const data = res?.data || null;
      setKyc(data);

      if (data) {
        setDraft({
          fullName: data.fullName || "",
          mobile: data.mobile || "",
          email: data.email || "",
          nidNumber: data.nidNumber || "",
        });
      }
    } catch (e) {
      setErr(e.message || "Failed to load");
    }
  }

  useEffect(() => {
    load();
  }, []);

  const status = normStatus(kyc?.verificationStatus);
  const locked = isLockedStatus(status);
  const editable = canEdit(status) && !locked;
  const hasDraft = !!kyc?.id;
  const step2Enabled = hasDraft;

  const haveTypes = useMemo(() => {
    const s = new Set((kyc?.documents || []).map((d) => String(d.type).toUpperCase()));
    return s;
  }, [kyc]);

  const missingRequired = useMemo(() => {
    return REQUIRED.filter((r) => !haveTypes.has(String(r.type).toUpperCase())).map((r) => r.type);
  }, [haveTypes]);

  async function saveDraft({ goNext = false } = {}) {
    if (locked) return;
    setLoading(true);
    setErr("");
    setMsg("");

    try {
      if (!draft.fullName?.trim()) throw new Error("Full name is required.");

      const res = await apiPut("/api/v1/owner/kyc", {
        fullName: draft.fullName,
        mobile: draft.mobile,
        email: draft.email,
        nidNumber: draft.nidNumber,
      });

      const data = res?.data || null;
      setKyc(data);

      setMsg("Draft saved. You can now upload documents.");
      await load();

      if (goNext) setStep(2);
    } catch (e) {
      setErr(e.message || "Failed to save");
    } finally {
      setLoading(false);
    }
  }

  async function uploadDoc(type, file, inputEl) {
    if (!file) return;

    if (locked) {
      setErr("KYC is approved/verified. Documents are locked.");
      return;
    }
    if (!editable) {
      setErr("KYC is not editable right now.");
      return;
    }
    if (!kyc?.id) {
      setErr("Please save Step-1 (KYC Information) first.");
      return;
    }

    setLoading(true);
    setUploadingType(type);
    setErr("");
    setMsg("");

    try {
      const base = String(process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3000").replace(/\/+$/, "");
      const fd = new FormData();
      fd.append("type", type);
      fd.append("file", file);

      const res = await fetch(`${base}/api/v1/owner/kyc/documents`, {
        method: "POST",
        credentials: "include",
        headers: { Accept: "application/json" },
        body: fd,
      });

      let payload = null;
      try {
        payload = await res.json();
      } catch {
        const t = await res.text().catch(() => "");
        payload = t ? { message: t } : null;
      }

      if (!res.ok) throw new Error(payload?.message || `Upload failed (${res.status})`);

      setMsg(`Uploaded: ${type}`);
      await load();

      if (inputEl) inputEl.value = "";
    } catch (e) {
      setErr(e.message || "Upload failed");
    } finally {
      setLoading(false);
      setUploadingType(null);
    }
  }

  async function submit() {
    if (locked) return;
    setLoading(true);
    setErr("");
    setMsg("");

    try {
      if (!kyc?.id) throw new Error("Please save KYC Information first.");
      if (missingRequired.length) throw new Error(`Please upload required documents first: ${missingRequired.join(", ")}`);

      const res = await apiPost("/api/v1/owner/kyc/submit", {});
      setKyc(res?.data || null);
      setMsg("Submitted for review");
      await load();
    } catch (e) {
      setErr(e.message || "Submit failed");
    } finally {
      setLoading(false);
    }
  }

  const docNidFront = findDoc(kyc?.documents, "NID_FRONT");
  const docNidBack = findDoc(kyc?.documents, "NID_BACK");
  const docSelfie = findDoc(kyc?.documents, "SELFIE_WITH_NID");

  const docsDisabled = isLockedStatus(status) || loading || !hasDraft;

  return (
    <div className="container-fluid">
      <div className="d-flex align-items-start justify-content-between flex-wrap gap-12 mb-16">
        <div>
          <h4 className="mb-6">Owner KYC</h4>
          <div className="text-secondary-light text-sm">
            Step 1: Save information. Step 2: Upload documents (crop/edit). After approval, everything becomes read-only.
          </div>
        </div>

        <div className="d-flex align-items-center gap-10">
          <div className="text-sm text-secondary-light">Status</div>
          <Badge text={status} />
        </div>
      </div>

      {locked ? (
        <Alert type="success">
          ✅ Your KYC is <b>{status}</b>. Everything is locked (view-only).
        </Alert>
      ) : status === "REQUEST_CHANGES" ? (
        <Alert type="warning">⚠️ Admin requested changes. Update your info/documents and submit again.</Alert>
      ) : status === "SUBMITTED" ? (
        <Alert type="info">⏳ Submitted and under review. You can still update information/documents until approval.</Alert>
      ) : null}

      {err ? <Alert type="danger">{err}</Alert> : null}
      {msg ? <Alert type="success">{msg}</Alert> : null}

      <Steps step={step} setStep={setStep} step2Enabled={step2Enabled} />

      {step === 1 ? (
        <div className="row g-3">
          <div className="col-12 col-xl-8">
            <div className="card border radius-16">
              <div className="card-body p-20">
                <div className="d-flex align-items-start justify-content-between mb-12">
                  <div>
                    <div className="fw-semibold">KYC Information</div>
                    <div className="text-sm text-secondary-light">Keep these details accurate.</div>
                  </div>
                  <span className={`text-xs fw-semibold ${editable ? "text-success-main" : "text-secondary-light"}`}>
                    {editable ? "Editable" : "Read-only"}
                  </span>
                </div>

                <div className="row g-3">
                  <div className="col-12">
                    <label className="form-label">Full name *</label>
                    <input
                      className="form-control"
                      value={draft.fullName}
                      disabled={isLockedStatus(status) || loading}
                      onChange={(e) => setDraft((s) => ({ ...s, fullName: e.target.value }))}
                    />
                  </div>

                  <div className="col-12 col-lg-6">
                    <label className="form-label">Mobile</label>
                    <input
                      className="form-control"
                      value={draft.mobile}
                      disabled={isLockedStatus(status) || loading}
                      onChange={(e) => setDraft((s) => ({ ...s, mobile: e.target.value }))}
                    />
                  </div>

                  <div className="col-12 col-lg-6">
                    <label className="form-label">Email</label>
                    <input
                      className="form-control"
                      value={draft.email}
                      disabled={isLockedStatus(status) || loading}
                      onChange={(e) => setDraft((s) => ({ ...s, email: e.target.value }))}
                    />
                  </div>

                  <div className="col-12 col-lg-6">
                    <label className="form-label">NID Number</label>
                    <input
                      className="form-control"
                      value={draft.nidNumber}
                      disabled={isLockedStatus(status) || loading}
                      onChange={(e) => setDraft((s) => ({ ...s, nidNumber: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="d-flex gap-10 flex-wrap mt-16">
                  <button className="btn btn-dark radius-12" disabled={isLockedStatus(status) || loading} onClick={() => saveDraft({ goNext: false })} type="button">
                    Save Draft
                  </button>

                  <button className="btn btn-primary radius-12" disabled={isLockedStatus(status) || loading} onClick={() => saveDraft({ goNext: true })} type="button">
                    Save & Continue
                  </button>
                </div>

                <div className="mt-12 text-xs text-secondary-light">
                  {hasDraft ? "Draft exists. You can proceed to Documents." : "Save draft to create your KYC record and unlock document upload."}
                </div>
              </div>
            </div>
          </div>

          <div className="col-12 col-xl-4">
            <div className="card border radius-16">
              <div className="card-body p-20">
                <div className="fw-semibold mb-8">What you’ll need</div>
                <div className="text-sm text-secondary-light">
                  • NID front & back (clear)
                  <br />• Selfie with NID
                  <br />• Correct name & contact details
                </div>
                <div className="border-top mt-12 pt-12 text-xs text-secondary-light">Tip: Use crop/edit in Step 2 to align/rotate images before upload.</div>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {step === 2 ? (
        <div className="row g-3">
          <div className="col-12">
            <div className="card border radius-16">
              <div className="card-body p-20">
                <div className="d-flex align-items-start justify-content-between mb-12 flex-wrap gap-10">
                  <div>
                    <div className="fw-semibold">Documents</div>
                    <div className="text-sm text-secondary-light">Upload clear images. Cropping/editing (move/zoom/rotate) is recommended.</div>
                  </div>

                  <span className={`text-xs fw-semibold ${!docsDisabled ? "text-success-main" : "text-secondary-light"}`}>
                    {locked ? "Locked" : !docsDisabled ? "Editable" : "Read-only"}
                  </span>
                </div>

                {!hasDraft ? <Alert type="warning">Save Step 1 first to enable uploads.</Alert> : null}

                <div className="row g-3">
                  <div className="col-12 col-lg-6">
                    <KycDocCard
                      label="NID Front"
                      hint="Upload NID front side"
                      type="NID_FRONT"
                      doc={docNidFront}
                      disabled={docsDisabled}
                      loading={loading}
                      uploading={uploadingType === "NID_FRONT"}
                      onUpload={uploadDoc}
                    />
                  </div>

                  <div className="col-12 col-lg-6">
                    <KycDocCard
                      label="NID Back"
                      hint="Upload NID back side"
                      type="NID_BACK"
                      doc={docNidBack}
                      disabled={docsDisabled}
                      loading={loading}
                      uploading={uploadingType === "NID_BACK"}
                      onUpload={uploadDoc}
                    />
                  </div>

                  <div className="col-12">
                    <KycDocCard
                      label="Selfie with NID"
                      hint="Selfie holding NID (clear face + readable NID)"
                      type="SELFIE_WITH_NID"
                      doc={docSelfie}
                      disabled={docsDisabled}
                      loading={loading}
                      uploading={uploadingType === "SELFIE_WITH_NID"}
                      onUpload={uploadDoc}
                    />
                  </div>
                </div>

                <div className="d-flex align-items-center justify-content-between flex-wrap gap-10 mt-16">
                  <div className="text-xs">
                    {missingRequired.length ? (
                      <span className="text-danger-main">
                        Missing required: <b>{missingRequired.join(", ")}</b>
                      </span>
                    ) : (
                      <span className="text-success-main">All required documents uploaded.</span>
                    )}
                  </div>

                  <div className="d-flex gap-10 flex-wrap">
                    <button className="btn btn-light radius-12" type="button" onClick={() => setStep(1)}>
                      Back to Info
                    </button>

                    <button
                      className="btn btn-primary radius-12"
                      disabled={locked || loading || !editable || !hasDraft || missingRequired.length > 0 || status === "SUBMITTED"}
                      onClick={submit}
                      type="button"
                    >
                      Submit for Review
                    </button>
                  </div>
                </div>

                <div className="mt-12 text-xs text-secondary-light">Note: After approval/verification, documents cannot be replaced or deleted.</div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
