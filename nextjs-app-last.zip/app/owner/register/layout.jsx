export default function OwnerRegisterLayout({ children }) {
  // Standalone auth layout (no sidebar/topbar)
  return <>{children}</>;
}
