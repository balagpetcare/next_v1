"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import { ownerGet } from "@/app/owner/_lib/ownerApi";

/**
 * Hook to fetch entity counts for menu badges
 * Only fetches when on owner panel
 */
export function useEntityCounts() {
  const pathname = usePathname();
  const isOwner = pathname?.startsWith("/owner");
  
  const [counts, setCounts] = useState({
    organizations: 0,
    branches: 0,
    staffs: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Only fetch if on owner panel
    if (!isOwner) {
      setLoading(false);
      return;
    }

    let cancelled = false;

    (async () => {
      try {
        const [orgsRes, branchesRes, staffsRes] = await Promise.allSettled([
          ownerGet("/api/v1/owner/organizations"),
          ownerGet("/api/v1/owner/branches"),
          ownerGet("/api/v1/owner/staffs"),
        ]);

        if (cancelled) return;

        const pickArray = (resp) => {
          if (!resp) return [];
          if (Array.isArray(resp)) return resp;
          if (Array.isArray(resp.data)) return resp.data;
          if (Array.isArray(resp.items)) return resp.items;
          return [];
        };

        const newCounts = {
          organizations:
            orgsRes.status === "fulfilled"
              ? pickArray(orgsRes.value).length
              : 0,
          branches:
            branchesRes.status === "fulfilled"
              ? pickArray(branchesRes.value).length
              : 0,
          staffs:
            staffsRes.status === "fulfilled"
              ? pickArray(staffsRes.value).length
              : 0,
        };

        setCounts(newCounts);
      } catch {
        // Silently fail - badges are optional
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [isOwner]);

  return { counts, loading };
}
