export default function OwnerLoginLayout({ children }) {
  // Standalone auth layout (no sidebar/topbar)
  return <>{children}</>;
}
