// @ts-nocheck
export { default } from "@/app/owner/kyc/page.jsx";
