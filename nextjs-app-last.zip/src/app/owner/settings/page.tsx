import Placeholder from "@/src/components/Placeholder";

export default function Page() {
  return <Placeholder title="settings" />;
}
